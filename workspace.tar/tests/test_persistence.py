"""Test persistence system."""

import pytest
import os
import json
from astra.core.persistence import PersistenceManager, Snapshot, SnapshotMetadata
from astra.core.exceptions import PersistenceError


def test_save_load(tmp_path):
    """Test basic save and load."""
    pm = PersistenceManager(str(tmp_path))
    
    data = {"key": "value", "number": 42}
    snapshot = pm.save(data, snapshot_id="test1", tick=10)
    
    loaded = pm.load("test1")
    
    assert loaded.data == data
    assert loaded.metadata.tick == 10


def test_checksum_verification(tmp_path):
    """Test checksum verification."""
    pm = PersistenceManager(str(tmp_path))
    
    data = {"test": "data"}
    snapshot = pm.save(data, snapshot_id="test2")
    
    # Verify passes
    loaded = pm.load("test2", verify=True)
    assert loaded.verify_integrity()


def test_corrupted_data(tmp_path):
    """Test detection of corrupted data."""
    pm = PersistenceManager(str(tmp_path))
    
    data = {"test": "data"}
    pm.save(data, snapshot_id="test3")
    
    # Corrupt the file
    path = os.path.join(str(tmp_path), "test3.json")
    with open(path, "w") as f:
        f.write("{ invalid json }")
    
    with pytest.raises(PersistenceError):
        pm.load("test3")


def test_list_snapshots(tmp_path):
    """Test listing snapshots."""
    pm = PersistenceManager(str(tmp_path))
    
    pm.save({"a": 1}, snapshot_id="snap_a")
    pm.save({"b": 2}, snapshot_id="snap_b")
    
    snapshots = pm.list_snapshots()
    
    assert "snap_a" in snapshots
    assert "snap_b" in snapshots
    assert len(snapshots) == 2
