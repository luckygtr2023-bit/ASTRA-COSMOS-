"""Test event system."""

import pytest
from astra.core.events import Event, EventBus, Priority


def test_subscribe_publish():
    """Test basic subscribe and publish."""
    bus = EventBus()
    received = []
    
    def handler(event):
        received.append(event)
    
    bus.subscribe("test_event", handler)
    bus.publish(Event(event_type="test_event"))
    
    assert len(received) == 1
    assert received[0].event_type == "test_event"


def test_priority_ordering():
    """Test that handlers are called in priority order."""
    bus = EventBus()
    order = []
    
    def low_handler(event):
        order.append("low")
    
    def high_handler(event):
        order.append("high")
    
    def normal_handler(event):
        order.append("normal")
    
    bus.subscribe("test", low_handler, Priority.LOW)
    bus.subscribe("test", high_handler, Priority.HIGH)
    bus.subscribe("test", normal_handler, Priority.NORMAL)
    
    bus.publish(Event(event_type="test"))
    
    assert order == ["high", "normal", "low"]


def test_wildcard_subscription():
    """Test wildcard subscription."""
    bus = EventBus()
    all_events = []
    
    def catch_all(event):
        all_events.append(event.event_type)
    
    bus.subscribe("*", catch_all)
    bus.subscribe("specific", lambda e: None)
    
    bus.publish(Event(event_type="event_a"))
    bus.publish(Event(event_type="event_b"))
    
    assert all_events == ["event_a", "event_b"]


def test_unsubscribe():
    """Test unsubscribe."""
    bus = EventBus()
    call_count = [0]
    
    def handler(event):
        call_count[0] += 1
    
    bus.subscribe("test", handler)
    bus.publish(Event(event_type="test"))
    assert call_count[0] == 1
    
    bus.unsubscribe("test", handler)
    bus.publish(Event(event_type="test"))
    assert call_count[0] == 1  # No change


def test_unsubscribe_all_by_owner():
    """Test bulk unsubscribe by owner."""
    bus = EventBus()
    calls = {"a": 0, "b": 0}
    
    bus.subscribe("test", lambda e: calls.__setitem__("a", calls["a"] + 1), owner="owner_a")
    bus.subscribe("test", lambda e: calls.__setitem__("b", calls["b"] + 1), owner="owner_b")
    
    bus.publish(Event(event_type="test"))
    assert calls["a"] == 1
    assert calls["b"] == 1
    
    bus.unsubscribe_all("owner_a")
    bus.publish(Event(event_type="test"))
    assert calls["a"] == 1  # No change
    assert calls["b"] == 2
