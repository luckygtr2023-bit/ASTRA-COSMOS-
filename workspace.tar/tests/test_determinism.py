"""Test deterministic command execution and replay."""

import pytest
from astra.core.commands import Command, CommandDispatcher, CommandHistory, CommandType
from astra.core.ids import reset_all_generators


def test_command_ordering():
    """Test that commands are ordered by tick and sequence."""
    dispatcher = CommandDispatcher()
    
    cmd1 = dispatcher.issue(CommandType.ENTITY_CREATE, {"name": "a"}, tick=0)
    cmd2 = dispatcher.issue(CommandType.ENTITY_CREATE, {"name": "b"}, tick=0)
    cmd3 = dispatcher.issue(CommandType.ENTITY_CREATE, {"name": "c"}, tick=1)
    
    assert cmd1.tick == 0
    assert cmd2.tick == 0
    assert cmd3.tick == 1
    
    assert cmd1.sequence < cmd2.sequence
    assert cmd2.sequence < cmd3.sequence


def test_command_comparison():
    """Test command comparison for sorting."""
    cmd1 = Command(CommandType.ENTITY_CREATE, tick=0, sequence=0)
    cmd2 = Command(CommandType.ENTITY_CREATE, tick=0, sequence=1)
    cmd3 = Command(CommandType.ENTITY_CREATE, tick=1, sequence=0)
    
    assert cmd1 < cmd2
    assert cmd2 < cmd3
    assert cmd1 < cmd3


def test_replay_preserves_order():
    """Test that replay preserves command ordering."""
    reset_all_generators()
    
    dispatcher1 = CommandDispatcher()
    cmds_run1 = []
    
    # Run simulation A
    for i in range(5):
        cmd = dispatcher1.issue(CommandType.ENTITY_CREATE, {"name": f"ent_{i}"})
        dispatcher1.execute_pending()
        cmds_run1.append(cmd.command_id)
        dispatcher1.advance_tick()
    
    # Reset and replay
    reset_all_generators()
    
    dispatcher2 = CommandDispatcher()
    cmds_run2 = []
    
    # Replay same commands
    for i in range(5):
        cmd = dispatcher2.issue(CommandType.ENTITY_CREATE, {"name": f"ent_{i}"})
        dispatcher2.execute_pending()
        cmds_run2.append(cmd.command_id)
        dispatcher2.advance_tick()
    
    # IDs should be identical
    assert cmds_run1 == cmds_run2


def test_command_history_recording():
    """Test that command history records executed commands."""
    dispatcher = CommandDispatcher()
    history = CommandHistory()
    
    cmd = dispatcher.issue(CommandType.ENTITY_CREATE, {"name": "test"})
    dispatcher.execute_pending()
    history.record(cmd)
    
    recorded = history.get_all_commands()
    assert len(recorded) == 1
    assert recorded[0].command_id == cmd.command_id
