"""Test deterministic RNG stream isolation."""

import pytest
from astra.core.rng import DeterministicRNG, RNGStream


def test_stream_isolation():
    """Test that streams don't affect each other."""
    rng = DeterministicRNG(default_seed=42)
    
    stream_a = rng.create_stream("stream_a", seed=100)
    stream_b = rng.create_stream("stream_b", seed=200)
    
    # Consume from stream_a
    a_vals = [stream_a.random() for _ in range(5)]
    
    # Consume from stream_b - should be unaffected
    b_vals = [stream_b.random() for _ in range(5)]
    
    # Reset and replay
    rng2 = DeterministicRNG(default_seed=42)
    stream_a2 = rng2.create_stream("stream_a", seed=100)
    stream_b2 = rng2.create_stream("stream_b", seed=200)
    
    a_vals2 = [stream_a2.random() for _ in range(5)]
    b_vals2 = [stream_b2.random() for _ in range(5)]
    
    assert a_vals == a_vals2
    assert b_vals == b_vals2


def test_stream_snapshot_restore():
    """Test stream snapshot and restore."""
    stream = RNGStream("test", seed=42)
    
    # Consume some values
    vals_before = [stream.random() for _ in range(3)]
    
    # Snapshot
    state = stream.snapshot()
    
    # Consume more
    vals_after = [stream.random() for _ in range(3)]
    
    # Restore
    stream.restore(state)
    
    # Should produce same values as after snapshot
    vals_restored = [stream.random() for _ in range(3)]
    
    assert vals_after == vals_restored


def test_stream_reset():
    """Test stream reset to initial state."""
    stream = RNGStream("test", seed=42)
    
    vals_original = [stream.random() for _ in range(5)]
    
    # Consume more
    [stream.random() for _ in range(10)]
    
    # Reset
    stream.reset()
    
    vals_reset = [stream.random() for _ in range(5)]
    
    assert vals_original == vals_reset
