"""Test simulation authority enforcement."""

import pytest
import threading
from astra.core.threading import SimulationThread, AuthorityContext
from astra.core.exceptions import AuthorityError


def test_authority_on_simulation_thread():
    """Test that operations on simulation thread are allowed."""
    sim = SimulationThread()
    sim.set_as_simulation_thread()
    
    # Should not raise
    sim.require_authority("test_operation")


def test_authority_violation_on_other_thread():
    """Test that operations from other threads are rejected."""
    sim = SimulationThread()
    sim.set_as_simulation_thread()
    
    violation_raised = threading.Event()
    
    def other_thread_func():
        try:
            sim.require_authority("test_operation")
        except AuthorityError:
            violation_raised.set()
    
    t = threading.Thread(target=other_thread_func)
    t.start()
    t.join()
    
    assert violation_raised.is_set(), "AuthorityError should be raised"


def test_nested_authority_context():
    """Test nested authority context."""
    sim = SimulationThread()
    sim.set_as_simulation_thread()
    
    violation_raised = threading.Event()
    
    def other_thread_func():
        try:
            with AuthorityContext(sim, "authorized_op"):
                # Should not raise inside context
                sim.require_authority("authorized_op")
        except AuthorityError:
            violation_raised.set()
    
    t = threading.Thread(target=other_thread_func)
    t.start()
    t.join()
    
    # Should have succeeded (no violation)
    assert not violation_raised.is_set()
