"""Test simulation time system."""

import pytest
from astra.core.time import SimulationClock, TimeMode, Timestamp
from astra.core.exceptions import TimeError


def test_clock_start_stop():
    """Test clock start and stop."""
    clock = SimulationClock()
    
    assert not clock.is_running
    
    clock.start()
    assert clock.is_running
    
    clock.stop()
    assert not clock.is_running


def test_clock_pause_resume():
    """Test clock pause and resume."""
    clock = SimulationClock()
    clock.start()
    
    assert not clock.is_paused
    
    clock.pause()
    assert clock.is_paused
    
    clock.resume()
    assert not clock.is_paused


def test_advance_ticks():
    """Test advancing ticks."""
    clock = SimulationClock(tick_rate=60.0)
    clock.start()
    
    initial_tick = clock.current_tick
    new_tick = clock.advance(1)
    
    assert new_tick == initial_tick + 1
    assert clock.current_tick == new_tick


def test_seek():
    """Test timeline seeking."""
    clock = SimulationClock(tick_rate=60.0)
    clock.start()
    
    clock.advance(10)
    assert clock.current_tick == 10
    
    clock.seek(5)
    assert clock.current_tick == 5
    assert clock.simulation_time == 5 / 60.0


def test_external_sync_mode():
    """Test external sync mode with monotonicity check."""
    clock = SimulationClock(mode=TimeMode.EXTERNAL_SYNC)
    clock.start()
    
    clock.update_external_timestamp(100.0)
    assert clock.simulation_time == 100.0
    
    clock.update_external_timestamp(200.0)
    assert clock.simulation_time == 200.0
    
    # Non-monotonic should fail
    with pytest.raises(TimeError):
        clock.update_external_timestamp(150.0)


def test_invalid_seek():
    """Test that invalid seeks are rejected."""
    clock = SimulationClock()
    clock.start()
    
    with pytest.raises(TimeError):
        clock.seek(-1)
