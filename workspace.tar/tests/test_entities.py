"""Test entity management."""

import pytest
from astra.core.entities import EntityManager, Entity, Component, ComponentQuery


def test_create_entity():
    """Test entity creation."""
    em = EntityManager()
    
    entity = em.create_entity(name="test")
    
    assert entity.name == "test"
    assert entity.active is True
    assert em.entity_exists(entity.entity_id)
    assert em.count() == 1


def test_destroy_entity():
    """Test entity destruction."""
    em = EntityManager()
    entity = em.create_entity(name="test")
    
    result = em.destroy_entity(entity.entity_id)
    
    assert result is True
    assert not em.entity_exists(entity.entity_id)
    assert em.count() == 0


def test_components():
    """Test component management."""
    em = EntityManager()
    entity = em.create_entity(name="test")
    
    comp = Component(component_type="position")
    entity.add_component(comp)
    
    assert entity.has_component("position")
    retrieved = entity.get_component("position")
    assert retrieved is comp
    
    removed = entity.remove_component("position")
    assert removed is comp
    assert not entity.has_component("position")


def test_query():
    """Test entity queries."""
    em = EntityManager()
    
    e1 = em.create_entity(name="player")
    e1.add_component(Component(component_type="renderable"))
    e1.add_component(Component(component_type="transform"))
    
    e2 = em.create_entity(name="enemy")
    e2.add_component(Component(component_type="renderable"))
    
    e3 = em.create_entity(name="light")
    
    # Query for renderable entities
    query = ComponentQuery("renderable")
    results = em.query(query)
    
    assert len(results) == 2
    assert e1 in results
    assert e2 in results


def test_safe_iteration():
    """Test safe iteration during modification."""
    em = EntityManager()
    
    e1 = em.create_entity(name="e1")
    e2 = em.create_entity(name="e2")
    e3 = em.create_entity(name="e3")
    
    # Iterate and collect IDs
    ids = []
    for entity in em.iterate_safe():
        ids.append(entity.entity_id)
        # Create new entity during iteration
        em.create_entity(name=f"new_{entity.name}")
    
    # Should have original 3 entities
    assert len(ids) == 3
    # But total count should be 6
    assert em.count() == 6
