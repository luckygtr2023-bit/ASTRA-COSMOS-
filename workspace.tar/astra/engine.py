"""
Main Engine implementation.

Provides the core engine lifecycle and state management.
"""

from __future__ import annotations
import threading
from typing import Dict, Any, Optional, Callable
from enum import Enum
from dataclasses import dataclass

from astra.core.logging import get_logger, set_log_level, LogLevel
from astra.core.config import EngineConfig, DeterminismMode, AuthorityMode
from astra.core.exceptions import EngineError, AuthorityError
from astra.core.threading import SimulationThread, check_authority
from astra.core.events import EventBus, Event
from astra.core.commands import CommandDispatcher, CommandHistory, CommandType, Command
from astra.core.time import SimulationClock, TimeMode
from astra.core.scene import Scene
from astra.core.rng import DeterministicRNG
from astra.core.persistence import PersistenceManager, Snapshot
from astra.core.resources import ResourceManager
from astra.core.recovery import RecoveryManager, RecoveryPolicy
from astra.core.services import ServiceRegistry

logger = get_logger("engine")


class EngineState(Enum):
    """Engine lifecycle states."""

    CREATED = "created"
    READY = "ready"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class EngineStatus:
    """Current engine status."""

    state: EngineState
    tick: int
    simulation_time: float
    entity_count: int
    error_message: str = ""


class Engine:
    """
    Main ASTRA engine.

    Provides lifecycle management and coordinates all core systems.
    """

    def __init__(self, config: Optional[EngineConfig] = None):
        self._config = config or EngineConfig()
        self._lock = threading.RLock()
        self._state = EngineState.CREATED
        
        # Core systems
        self._sim_thread = SimulationThread()
        self._event_bus = EventBus()
        self._command_dispatcher = CommandDispatcher()
        self._command_history = CommandHistory(self._config.max_command_history)
        self._clock = SimulationClock()
        self._scene = Scene()
        self._rng = DeterministicRNG()
        self._persistence = PersistenceManager(self._config.persistence_path)
        self._resources = ResourceManager(self._config.resource_limit)
        self._recovery = RecoveryManager(
            RecoveryPolicy(self._config.recovery_policy)
        )
        self._services = ServiceRegistry()
        
        # Tick callback
        self._tick_callbacks: list[Callable[[int], None]] = []
        
        logger.info("Engine created")

    @property
    def state(self) -> EngineState:
        return self._state

    @property
    def config(self) -> EngineConfig:
        return self._config

    @property
    def sim_thread(self) -> SimulationThread:
        return self._sim_thread

    @property
    def event_bus(self) -> EventBus:
        return self._event_bus

    @property
    def command_dispatcher(self) -> CommandDispatcher:
        return self._command_dispatcher

    @property
    def clock(self) -> SimulationClock:
        return self._clock

    @property
    def scene(self) -> Scene:
        return self._scene

    @property
    def rng(self) -> DeterministicRNG:
        return self._rng

    @property
    def persistence(self) -> PersistenceManager:
        return self._persistence

    @property
    def resources(self) -> ResourceManager:
        return self._resources

    @property
    def recovery(self) -> RecoveryManager:
        return self._recovery

    @property
    def services(self) -> ServiceRegistry:
        return self._services

    def initialize(self) -> "Engine":
        """Initialize the engine."""
        with self._lock:
            if self._state != EngineState.CREATED:
                raise EngineError(f"Cannot initialize from state: {self._state}")
            
            # Validate config
            errors = self._config.validate()
            if errors:
                raise EngineError(f"Invalid configuration: {errors}")
            
            # Set up simulation thread
            self._sim_thread.set_as_simulation_thread()
            
            # Register internal command handlers
            self._setup_command_handlers()
            
            self._state = EngineState.READY
            logger.info("Engine initialized")
            
            # Emit event
            self._event_bus.publish(Event(
                event_type="engine_initialized",
                source="engine",
                data={"config": self._config.to_dict()},
            ))
            
            return self

    def _setup_command_handlers(self) -> None:
        """Set up internal command handlers."""
        self._command_dispatcher.register_handler(
            CommandType.ENTITY_CREATE,
            self._handle_entity_create
        )
        self._command_dispatcher.register_handler(
            CommandType.ENTITY_DESTROY,
            self._handle_entity_destroy
        )

    def _handle_entity_create(self, cmd: Command) -> Any:
        """Handle entity creation command."""
        name = cmd.payload.get("name", "")
        entity = self._scene.entities.create_entity(name=name)
        return entity.entity_id

    def _handle_entity_destroy(self, cmd: Command) -> Any:
        """Handle entity destruction command."""
        entity_id = cmd.payload.get("entity_id")
        return self._scene.entities.destroy_entity(entity_id)

    def start(self) -> None:
        """Start the engine."""
        with self._lock:
            if self._state not in (EngineState.READY, EngineState.PAUSED):
                raise EngineError(f"Cannot start from state: {self._state}")
            
            self._clock.start()
            self._services.start_all()
            self._state = EngineState.RUNNING
            logger.info("Engine started")
            
            self._event_bus.publish(Event(
                event_type="engine_started",
                source="engine",
            ))

    def stop(self) -> None:
        """Stop the engine."""
        with self._lock:
            if self._state not in (EngineState.RUNNING, EngineState.PAUSED):
                return
            
            self._clock.stop()
            self._services.stop_all()
            self._state = EngineState.STOPPED
            logger.info("Engine stopped")
            
            self._event_bus.publish(Event(
                event_type="engine_stopped",
                source="engine",
            ))

    def pause(self) -> None:
        """Pause the engine."""
        with self._lock:
            if self._state != EngineState.RUNNING:
                raise EngineError(f"Cannot pause from state: {self._state}")
            
            self._clock.pause()
            self._services.pause_all() if hasattr(self._services, 'pause_all') else None
            self._state = EngineState.PAUSED
            logger.info("Engine paused")

    def resume(self) -> None:
        """Resume the engine."""
        with self._lock:
            if self._state != EngineState.PAUSED:
                raise EngineError(f"Cannot resume from state: {self._state}")
            
            self._clock.resume()
            self._state = EngineState.RUNNING
            logger.info("Engine resumed")

    def tick(self) -> int:
        """
        Advance simulation by one tick.

        Must be called from simulation thread.
        """
        check_authority(self._sim_thread, "tick")
        
        with self._lock:
            if self._state != EngineState.RUNNING:
                return self._clock.current_tick
            
            # Advance clock
            new_tick = self._clock.advance(1)
            
            # Execute pending commands
            results = self._command_dispatcher.execute_pending()
            for cmd, result in results:
                self._command_history.record(cmd)
            
            # Advance scene
            self._scene.advance_tick()
            
            # Notify callbacks
            for callback in self._tick_callbacks:
                try:
                    callback(new_tick)
                except Exception as e:
                    logger.error(f"Tick callback error: {e}")
            
            return new_tick

    def issue_command(
        self,
        command_type: CommandType,
        payload: Dict[str, Any] = None,
    ) -> Command:
        """Issue a command for execution."""
        cmd = self._command_dispatcher.issue(command_type, payload)
        return cmd

    def save(self, snapshot_id: Optional[str] = None) -> Snapshot:
        """Save current state to a snapshot."""
        check_authority(self._sim_thread, "save")
        
        data = {
            "clock": self._clock.snapshot(),
            "scene": self._scene.snapshot(),
            "rng": self._rng.snapshot_all(),
            "commands": self._command_history.snapshot(),
        }
        
        return self._persistence.save(
            data=data,
            snapshot_id=snapshot_id,
            tick=self._clock.current_tick,
        )

    def load(self, snapshot_id: str) -> Snapshot:
        """Load state from a snapshot."""
        check_authority(self._sim_thread, "load")
        
        snapshot = self._persistence.load(snapshot_id)
        data = snapshot.data
        
        if "clock" in data:
            self._clock.restore(data["clock"])
        if "scene" in data:
            self._scene.restore(data["scene"])
        if "rng" in data:
            self._rng.restore_all(data["rng"])
        if "commands" in data:
            self._command_history.restore(data["commands"])
        
        return snapshot

    def get_status(self) -> EngineStatus:
        """Get current engine status."""
        return EngineStatus(
            state=self._state,
            tick=self._clock.current_tick,
            simulation_time=self._clock.simulation_time,
            entity_count=self._scene.entities.count(),
        )

    def register_tick_callback(self, callback: Callable[[int], None]) -> None:
        """Register a callback for tick events."""
        self._tick_callbacks.append(callback)

    def shutdown(self) -> None:
        """Shutdown the engine completely."""
        try:
            self.stop()
        except Exception as e:
            logger.error(f"Error during shutdown: {e}")
        
        self._resources.clear()
        self._services.stop_all()
        logger.info("Engine shutdown complete")
