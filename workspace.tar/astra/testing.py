"""
Testing utilities for ASTRA CORE.

Provides helpers for deterministic testing.
"""

from __future__ import annotations
import threading
from typing import Any, Dict, Optional

from astra.core.ids import reset_all_generators, set_counter
from astra.core.rng import DeterministicRNG
from astra.core.commands import CommandHistory
from astra.core.events import EventBus


def reset_for_replay() -> None:
    """Reset all ID generators for deterministic replay."""
    reset_all_generators()


class TestContext:
    """Context manager for test setup/teardown."""

    def __init__(self):
        self._saved_state: Dict[str, Any] = {}

    def __enter__(self) -> "TestContext":
        reset_for_replay()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        reset_for_replay()
        return False  # Don't suppress exceptions


def assert_deterministic_equal(a: Any, b: Any, msg: str = "") -> None:
    """Assert two values are deterministically equal."""
    if a != b:
        raise AssertionError(f"{msg}: {a!r} != {b!r}")
