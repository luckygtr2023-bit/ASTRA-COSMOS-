"""
ASTRA - Astronomy Simulation & Trajectory Rendering Architecture

CORE v0.1.1 - Foundational runtime layer
"""

__version__ = "0.1.1"
__author__ = "ASTRA Team"

from astra.core.exceptions import (
    AstraError,
    EngineError,
    AuthorityError,
    CommandError,
    EntityError,
    FrameError,
    TimeError,
    ResourceError,
    PersistenceError,
)

from astra.engine import Engine, EngineState
from astra.core.time import SimulationClock, TimeMode
from astra.core.commands import Command, CommandDispatcher, CommandHistory
from astra.core.entities import Entity, EntityManager, Component
from astra.core.events import Event, EventBus, EventHandler, Priority
from astra.core.rng import DeterministicRNG, RNGStream
from astra.core.coords import Frame, FrameRegistry, CoordinateTransform
from astra.core.scene import Scene, SceneState
from astra.core.persistence import PersistenceManager, Snapshot, SnapshotMetadata
from astra.core.resources import ResourceManager, ResourceHandle, ResourceType
from astra.core.recovery import RecoveryPolicy, RecoveryBoundary
from astra.core.config import EngineConfig
from astra.core.logging import get_logger, set_log_level, LogLevel

__all__ = [
    # Version
    "__version__",
    "__author__",
    # Engine
    "Engine",
    "EngineState",
    # Core exceptions
    "AstraError",
    "EngineError",
    "AuthorityError",
    "CommandError",
    "EntityError",
    "FrameError",
    "TimeError",
    "ResourceError",
    "PersistenceError",
    # Time
    "SimulationClock",
    "TimeMode",
    # Commands
    "Command",
    "CommandDispatcher",
    "CommandHistory",
    # Entities
    "Entity",
    "EntityManager",
    "Component",
    # Events
    "Event",
    "EventBus",
    "EventHandler",
    "Priority",
    # RNG
    "DeterministicRNG",
    "RNGStream",
    # Coordinates/Frames
    "Frame",
    "FrameRegistry",
    "CoordinateTransform",
    # Scene
    "Scene",
    "SceneState",
    # Persistence
    "PersistenceManager",
    "Snapshot",
    "SnapshotMetadata",
    # Resources
    "ResourceManager",
    "ResourceHandle",
    "ResourceType",
    # Recovery
    "RecoveryPolicy",
    "RecoveryBoundary",
    # Config/Logging
    "EngineConfig",
    "get_logger",
    "set_log_level",
    "LogLevel",
]
