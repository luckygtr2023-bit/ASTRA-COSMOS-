"""
Recovery boundaries.

Provides recovery policies for handling failures.
"""

from __future__ import annotations
from enum import Enum
from typing import Optional, Callable, Any, TypeVar, Generic
from dataclasses import dataclass

from astra.core.logging import get_logger

logger = get_logger("recovery")


class RecoveryPolicy(Enum):
    """Recovery policy for failures."""

    FAIL_FAST = "fail_fast"  # Immediately propagate errors
    RETRY_STEP = "retry_step"  # Retry the failed operation
    DROP_EVENT = "drop_event"  # Drop the failing event/command
    ROLLBACK = "rollback"  # Rollback to last known good state


T = TypeVar("T")


@dataclass
class RecoveryBoundary:
    """
    Defines a recovery boundary with specific policy.

    A recovery boundary marks where failures should be handled
    according to the specified policy.
    """

    name: str
    policy: RecoveryPolicy = RecoveryPolicy.FAIL_FAST
    max_retries: int = 3
    on_failure: Optional[Callable[[Exception], None]] = None

    def execute(
        self,
        operation: Callable[[], T],
        fallback: Optional[Callable[[], T]] = None,
    ) -> Optional[T]:
        """
        Execute an operation within this recovery boundary.

        Args:
            operation: The operation to execute.
            fallback: Optional fallback function if operation fails.

        Returns:
            Result of operation or fallback, or None if all fail.
        """
        retries = 0
        
        while True:
            try:
                return operation()
            except Exception as e:
                logger.error(f"Operation failed in {self.name}: {e}")
                
                if self.on_failure:
                    try:
                        self.on_failure(e)
                    except Exception as fe:
                        logger.error(f"on_failure callback failed: {fe}")
                
                if self.policy == RecoveryPolicy.FAIL_FAST:
                    raise
                
                elif self.policy == RecoveryPolicy.RETRY_STEP:
                    retries += 1
                    if retries > self.max_retries:
                        if fallback:
                            logger.info(f"Using fallback after {retries} retries")
                            return fallback()
                        raise
                    logger.debug(f"Retrying ({retries}/{self.max_retries})")
                    continue
                
                elif self.policy == RecoveryPolicy.DROP_EVENT:
                    logger.warning(f"Dropping failed operation in {self.name}")
                    return None
                
                elif self.policy == RecoveryPolicy.ROLLBACK:
                    if fallback:
                        return fallback()
                    raise
                
                break
        
        return None

    def wrap(self, func: Callable[..., T]) -> Callable[..., Optional[T]]:
        """Wrap a function with this recovery boundary."""
        def wrapped(*args, **kwargs) -> Optional[T]:
            def operation():
                return func(*args, **kwargs)
            return self.execute(operation)
        return wrapped


class RecoveryManager:
    """Manages recovery boundaries for the engine."""

    def __init__(self, default_policy: RecoveryPolicy = RecoveryPolicy.FAIL_FAST):
        self._default_policy = default_policy
        self._boundaries: dict[str, RecoveryBoundary] = {}

    def create_boundary(
        self,
        name: str,
        policy: Optional[RecoveryPolicy] = None,
        max_retries: int = 3,
    ) -> RecoveryBoundary:
        """Create a named recovery boundary."""
        boundary = RecoveryBoundary(
            name=name,
            policy=policy or self._default_policy,
            max_retries=max_retries,
        )
        self._boundaries[name] = boundary
        return boundary

    def get_boundary(self, name: str) -> Optional[RecoveryBoundary]:
        """Get a boundary by name."""
        return self._boundaries.get(name)

    def remove_boundary(self, name: str) -> bool:
        """Remove a boundary."""
        if name in self._boundaries:
            del self._boundaries[name]
            return True
        return False
