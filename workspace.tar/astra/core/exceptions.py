"""
ASTRA Core Exceptions

All exceptions in ASTRA CORE inherit from AstraError.
"""

from __future__ import annotations
from typing import Optional


class AstraError(Exception):
    """Base exception for all ASTRA errors."""

    def __init__(self, message: str, details: Optional[dict] = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def __str__(self) -> str:
        if self.details:
            return f"{self.message}: {self.details}"
        return self.message


class EngineError(AstraError):
    """Engine lifecycle or state error."""

    pass


class AuthorityError(AstraError):
    """Simulation authority violation.

    Raised when code attempts to mutate authoritative simulation state
    outside the authorized simulation thread/context.
    """

    pass


class CommandError(AstraError):
    """Command execution or validation error."""

    pass


class EntityError(AstraError):
    """Entity management error.

    Raised for invalid entity operations such as:
    - Creating an entity with an existing ID
    - Accessing a destroyed entity
    - Invalid component operations
    """

    pass


class FrameError(AstraError):
    """Coordinate frame error.

    Raised for invalid frame operations such as:
    - Registering a frame with an existing ID
    - Invalid parent relationships (cycles)
    - Unknown frame references
    """

    pass


class TimeError(AstraError):
    """Simulation time error.

    Raised for invalid time operations such as:
    - Backward timestamps in external sync mode
    - Invalid time mode transitions
    """

    pass


class ResourceError(AstraError):
    """Resource management error.

    Raised for:
    - Unknown resource acquisition
    - Double release
    - Invalid reference count operations
    """

    pass


class PersistenceError(AstraError):
    """Persistence system error.

    Raised for:
    - Save failures
    - Load failures
    - Integrity verification failures
    - Schema incompatibility
    """

    pass


class RecoveryError(AstraError):
    """Recovery boundary error."""

    pass
