"""
ASTRA CORE - Foundational runtime layer for the ASTRA simulation engine.

This module provides the core infrastructure required by all ASTRA subsystems:
- Engine lifecycle management
- Simulation authority enforcement
- Deterministic command execution
- Entity/component management
- Event system
- Deterministic RNG
- Coordinate/frame foundations
- Origin rebasing
- Simulation time
- Persistence
- Resource management
- Recovery boundaries
"""

from astra.core.exceptions import (
    AstraError,
    EngineError,
    AuthorityError,
    CommandError,
    EntityError,
    FrameError,
    TimeError,
    ResourceError,
    PersistenceError,
)
from astra.core.ids import generate_entity_id, generate_command_id, generate_event_id
from astra.core.logging import get_logger, set_log_level, LogLevel
from astra.core.config import EngineConfig
from astra.core.threading import SimulationThread, AuthorityContext
from astra.core.events import Event, EventBus, EventHandler, Priority
from astra.core.rng import DeterministicRNG, RNGStream
from astra.core.commands import Command, CommandDispatcher, CommandHistory, CommandType
from astra.core.entities import Entity, EntityManager, Component, ComponentQuery
from astra.core.coords import Frame, FrameRegistry, CoordinateTransform, RebaseRequest
from astra.core.time import SimulationClock, TimeMode, Timestamp
from astra.core.scene import Scene, SceneState
from astra.core.persistence import PersistenceManager, Snapshot, SnapshotMetadata
from astra.core.resources import ResourceManager, ResourceHandle, ResourceType
from astra.core.recovery import RecoveryPolicy, RecoveryBoundary
from astra.core.services import ServiceRegistry, Service, ServiceLifecycle

__all__ = [
    # Exceptions
    "AstraError",
    "EngineError",
    "AuthorityError",
    "CommandError",
    "EntityError",
    "FrameError",
    "TimeError",
    "ResourceError",
    "PersistenceError",
    # IDs
    "generate_entity_id",
    "generate_command_id",
    "generate_event_id",
    # Logging
    "get_logger",
    "set_log_level",
    "LogLevel",
    # Config
    "EngineConfig",
    # Threading/Authority
    "SimulationThread",
    "AuthorityContext",
    # Events
    "Event",
    "EventBus",
    "EventHandler",
    "Priority",
    # RNG
    "DeterministicRNG",
    "RNGStream",
    # Commands
    "Command",
    "CommandDispatcher",
    "CommandHistory",
    "CommandType",
    # Entities
    "Entity",
    "EntityManager",
    "Component",
    "ComponentQuery",
    # Coordinates/Frames
    "Frame",
    "FrameRegistry",
    "CoordinateTransform",
    "RebaseRequest",
    # Time
    "SimulationClock",
    "TimeMode",
    "Timestamp",
    # Scene
    "Scene",
    "SceneState",
    # Persistence
    "PersistenceManager",
    "Snapshot",
    "SnapshotMetadata",
    # Resources
    "ResourceManager",
    "ResourceHandle",
    "ResourceType",
    # Recovery
    "RecoveryPolicy",
    "RecoveryBoundary",
    # Services
    "ServiceRegistry",
    "Service",
    "ServiceLifecycle",
]
