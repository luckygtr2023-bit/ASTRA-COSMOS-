"""
Threading and simulation authority enforcement.

Ensures that only the authorized simulation thread can mutate
authoritative simulation state.
"""

from __future__ import annotations
import threading
import contextlib
from typing import Optional, Callable, Any, TypeVar, List
from dataclasses import dataclass
from enum import Enum

from astra.core.exceptions import AuthorityError
from astra.core.logging import get_logger

logger = get_logger("threading")


class ThreadRole(Enum):
    """Role of a thread in the simulation."""

    SIMULATION = "simulation"  # Authorized to mutate simulation state
    EXTERNAL = "external"  # External threads (I/O, UI, etc.)
    WORKER = "worker"  # Worker threads for parallel computation


@dataclass
class ThreadInfo:
    """Information about a registered thread."""

    thread_id: int
    name: str
    role: ThreadRole
    started_at: float


T = TypeVar("T")


class SimulationThread:
    """
    Manages the authoritative simulation thread.

    Only code executing on the simulation thread may mutate
    authoritative simulation state.
    """

    def __init__(self):
        self._sim_thread: Optional[threading.Thread] = None
        self._sim_thread_id: Optional[int] = None
        self._lock = threading.Lock()
        self._registered_threads: dict[int, ThreadInfo] = {}
        self._authority_stack: list[int] = []  # Stack for nested authority contexts

    def set_as_simulation_thread(self) -> None:
        """Mark the current thread as the simulation thread."""
        with self._lock:
            self._sim_thread = threading.current_thread()
            self._sim_thread_id = threading.get_ident()
            self._register_thread(ThreadRole.SIMULATION)
            logger.info(f"Set simulation thread: {self._sim_thread.name}")

    def is_simulation_thread(self) -> bool:
        """Check if the current thread is the simulation thread."""
        return threading.get_ident() == self._sim_thread_id

    def require_authority(self, operation: str = "operation") -> None:
        """
        Require that the current thread has simulation authority.

        Args:
            operation: Name of the operation for error messages.

        Raises:
            AuthorityError: If called from a non-simulation thread.
        """
        if not self.is_simulation_thread() and not self._has_nested_authority():
            raise AuthorityError(
                f"Unauthorized mutation: {operation} must be called "
                f"from the simulation thread",
                {"current_thread": threading.current_thread().name, "operation": operation},
            )

    def _register_thread(self, role: ThreadRole) -> ThreadInfo:
        """Register a thread with a specific role."""
        tid = threading.get_ident()
        info = ThreadInfo(
            thread_id=tid,
            name=threading.current_thread().name,
            role=role,
            started_at=threading.time(),
        )
        self._registered_threads[tid] = info
        return info

    def _has_nested_authority(self) -> bool:
        """Check if there's a nested authority context active."""
        return len(self._authority_stack) > 0

    def get_thread_info(self, thread_id: Optional[int] = None) -> Optional[ThreadInfo]:
        """Get information about a registered thread."""
        tid = thread_id or threading.get_ident()
        return self._registered_threads.get(tid)

    def reset(self) -> None:
        """Reset the simulation thread (for testing)."""
        with self._lock:
            self._sim_thread = None
            self._sim_thread_id = None
            self._registered_threads.clear()
            self._authority_stack.clear()


class AuthorityContext(contextlib.AbstractContextManager):
    """
    Context manager for temporarily granting authority.

    This allows controlled mutation of simulation state from
    non-simulation threads when explicitly authorized.

    WARNING: Use with extreme caution. This bypasses the normal
    authority checks and should only be used for specific operations
    that are known to be safe.
    """

    def __init__(self, sim_thread: SimulationThread, operation: str = "authorized_operation"):
        self._sim_thread = sim_thread
        self._operation = operation
        self._thread_id = threading.get_ident()

    def __enter__(self) -> "AuthorityContext":
        self._sim_thread._authority_stack.append(self._thread_id)
        logger.debug(f"Authority granted for: {self._operation}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        self._sim_thread._authority_stack.pop()
        logger.debug(f"Authority released for: {self._operation}")
        return False  # Don't suppress exceptions


def check_authority(sim_thread: SimulationThread, operation: str = "operation") -> None:
    """
    Convenience function to check authority.

    Args:
        sim_thread: The simulation thread manager.
        operation: Name of the operation for error messages.

    Raises:
        AuthorityError: If not on the simulation thread.
    """
    sim_thread.require_authority(operation)
