"""
Persistence system.

Provides atomic save/load with integrity verification.
"""

from __future__ import annotations
import json
import hashlib
import threading
import os
import tempfile
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime

from astra.core.logging import get_logger
from astra.core.exceptions import PersistenceError

logger = get_logger("persistence")


SCHEMA_VERSION = "1.0.0"


@dataclass
class SnapshotMetadata:
    """Metadata for a snapshot."""

    snapshot_id: str
    created_at: str
    schema_version: str = SCHEMA_VERSION
    engine_version: str = "0.1.1"
    tick: int = 0
    checksum: str = ""
    size_bytes: int = 0
    custom: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Snapshot:
    """A complete simulation snapshot."""

    metadata: SnapshotMetadata
    data: Dict[str, Any] = field(default_factory=dict)

    def compute_checksum(self) -> str:
        """Compute checksum of snapshot data."""
        content = json.dumps(self.data, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()

    def verify_integrity(self) -> bool:
        """Verify snapshot integrity."""
        if not self.metadata.checksum:
            return False
        return self.compute_checksum() == self.metadata.checksum


class PersistenceManager:
    """
    Manages persistence operations.

    Provides atomic writes and integrity verification.
    """

    def __init__(self, base_path: str = "./astra_snapshots"):
        self._base_path = base_path
        self._lock = threading.RLock()
        self._snapshots: Dict[str, Snapshot] = {}
        
        # Ensure directory exists
        os.makedirs(base_path, exist_ok=True)

    def _get_snapshot_path(self, snapshot_id: str) -> str:
        """Get file path for a snapshot."""
        return os.path.join(self._base_path, f"{snapshot_id}.json")

    def save(
        self,
        data: Dict[str, Any],
        snapshot_id: Optional[str] = None,
        tick: int = 0,
        custom: Optional[Dict[str, Any]] = None,
    ) -> Snapshot:
        """
        Save a snapshot atomically.

        Args:
            data: Data to persist.
            snapshot_id: Optional ID (auto-generated if not provided).
            tick: Current simulation tick.
            custom: Custom metadata.

        Returns:
            The saved Snapshot.
        """
        with self._lock:
            import uuid
            sid = snapshot_id or f"snapshot_{uuid.uuid4().hex[:12]}"
            
            metadata = SnapshotMetadata(
                snapshot_id=sid,
                created_at=datetime.utcnow().isoformat(),
                tick=tick,
                custom=custom or {},
            )
            
            snapshot = Snapshot(metadata=metadata, data=data)
            snapshot.metadata.checksum = snapshot.compute_checksum()
            
            # Atomic write: write to temp file then rename
            path = self._get_snapshot_path(sid)
            temp_path = path + ".tmp"
            
            try:
                serialized = json.dumps({
                    "metadata": {
                        "snapshot_id": snapshot.metadata.snapshot_id,
                        "created_at": snapshot.metadata.created_at,
                        "schema_version": snapshot.metadata.schema_version,
                        "engine_version": snapshot.metadata.engine_version,
                        "tick": snapshot.metadata.tick,
                        "checksum": snapshot.metadata.checksum,
                        "size_bytes": 0,  # Will update after write
                        "custom": snapshot.metadata.custom,
                    },
                    "data": snapshot.data,
                }, indent=2)
                
                snapshot.metadata.size_bytes = len(serialized.encode())
                
                # Rewrite with updated size
                serialized = json.dumps({
                    "metadata": {
                        "snapshot_id": snapshot.metadata.snapshot_id,
                        "created_at": snapshot.metadata.created_at,
                        "schema_version": snapshot.metadata.schema_version,
                        "engine_version": snapshot.metadata.engine_version,
                        "tick": snapshot.metadata.tick,
                        "checksum": snapshot.metadata.checksum,
                        "size_bytes": snapshot.metadata.size_bytes,
                        "custom": snapshot.metadata.custom,
                    },
                    "data": snapshot.data,
                }, indent=2)
                
                with open(temp_path, "w") as f:
                    f.write(serialized)
                    f.flush()
                    os.fsync(f.fileno())
                
                # Atomic rename
                os.rename(temp_path, path)
                
                self._snapshots[sid] = snapshot
                logger.info(f"Saved snapshot: {sid} ({snapshot.metadata.size_bytes} bytes)")
                
                return snapshot
                
            except Exception as e:
                # Clean up temp file on failure
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise PersistenceError(f"Save failed: {e}")

    def load(self, snapshot_id: str, verify: bool = True) -> Snapshot:
        """
        Load a snapshot.

        Args:
            snapshot_id: ID of snapshot to load.
            verify: Whether to verify checksum.

        Returns:
            The loaded Snapshot.
        """
        with self._lock:
            if snapshot_id in self._snapshots:
                return self._snapshots[snapshot_id]
            
            path = self._get_snapshot_path(snapshot_id)
            
            if not os.path.exists(path):
                raise PersistenceError(f"Snapshot not found: {snapshot_id}")
            
            try:
                with open(path, "r") as f:
                    content = f.read()
                
                parsed = json.loads(content)
                
                meta_data = parsed.get("metadata", {})
                metadata = SnapshotMetadata(
                    snapshot_id=meta_data.get("snapshot_id", snapshot_id),
                    created_at=meta_data.get("created_at", ""),
                    schema_version=meta_data.get("schema_version", SCHEMA_VERSION),
                    engine_version=meta_data.get("engine_version", "0.1.1"),
                    tick=meta_data.get("tick", 0),
                    checksum=meta_data.get("checksum", ""),
                    size_bytes=meta_data.get("size_bytes", 0),
                    custom=meta_data.get("custom", {}),
                )
                
                snapshot = Snapshot(
                    metadata=metadata,
                    data=parsed.get("data", {}),
                )
                
                if verify and not snapshot.verify_integrity():
                    raise PersistenceError(
                        f"Checksum verification failed for {snapshot_id}"
                    )
                
                # Schema version check
                if metadata.schema_version != SCHEMA_VERSION:
                    logger.warning(
                        f"Schema version mismatch: {metadata.schema_version} "
                        f"vs expected {SCHEMA_VERSION}"
                    )
                
                self._snapshots[snapshot_id] = snapshot
                logger.info(f"Loaded snapshot: {snapshot_id}")
                
                return snapshot
                
            except json.JSONDecodeError as e:
                raise PersistenceError(f"Corrupted snapshot data: {e}")
            except PersistenceError:
                raise
            except Exception as e:
                raise PersistenceError(f"Load failed: {e}")

    def delete(self, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        with self._lock:
            path = self._get_snapshot_path(snapshot_id)
            
            if os.path.exists(path):
                os.remove(path)
                self._snapshots.pop(snapshot_id, None)
                logger.info(f"Deleted snapshot: {snapshot_id}")
                return True
            
            return False

    def list_snapshots(self) -> list[str]:
        """List available snapshot IDs."""
        with self._lock:
            snapshots = []
            if os.path.exists(self._base_path):
                for f in os.listdir(self._base_path):
                    if f.endswith(".json"):
                        snapshots.append(f[:-5])  # Remove .json
            return snapshots

    def clear(self) -> None:
        """Clear all cached snapshots."""
        with self._lock:
            self._snapshots.clear()
