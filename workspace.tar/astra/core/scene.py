"""
Scene management.

Provides scene state container for simulation.
"""

from __future__ import annotations
import threading
from typing import Dict, Any, Optional
from dataclasses import dataclass, field

from astra.core.entities import EntityManager, Entity
from astra.core.coords import FrameRegistry


@dataclass
class SceneState:
    """Snapshot of scene state."""

    entity_count: int = 0
    frame_count: int = 0
    tick: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


class Scene:
    """
    Container for simulation scene.

    Manages entities and frames within a scene context.
    """

    def __init__(self, name: str = "default"):
        self._lock = threading.RLock()
        self._name = name
        self._entity_manager = EntityManager()
        self._frame_registry = FrameRegistry()
        self._metadata: Dict[str, Any] = {}
        self._tick: int = 0

    @property
    def name(self) -> str:
        return self._name

    @property
    def entities(self) -> EntityManager:
        return self._entity_manager

    @property
    def frames(self) -> FrameRegistry:
        return self._frame_registry

    @property
    def tick(self) -> int:
        return self._tick

    def advance_tick(self) -> int:
        """Advance scene tick."""
        with self._lock:
            self._tick += 1
            return self._tick

    def get_state(self) -> SceneState:
        """Get current scene state."""
        with self._lock:
            return SceneState(
                entity_count=self._entity_manager.count(),
                frame_count=self._frames.count(),
                tick=self._tick,
                metadata=dict(self._metadata),
            )

    def set_metadata(self, key: str, value: Any) -> None:
        """Set scene metadata."""
        with self._lock:
            self._metadata[key] = value

    def get_metadata(self, key: str, default: Any = None) -> Any:
        """Get scene metadata."""
        return self._metadata.get(key, default)

    def snapshot(self) -> Dict[str, Any]:
        """Create serializable snapshot."""
        with self._lock:
            return {
                "name": self._name,
                "tick": self._tick,
                "entities": self._entity_manager.snapshot(),
                "frames": self._frames.snapshot(),
                "metadata": dict(self._metadata),
            }

    def restore(self, snapshot: Dict[str, Any]) -> None:
        """Restore from snapshot."""
        with self._lock:
            self._name = snapshot.get("name", "default")
            self._tick = snapshot.get("tick", 0)
            self._metadata = dict(snapshot.get("metadata", {}))
            
            if "entities" in snapshot:
                self._entity_manager.restore(snapshot["entities"])
            if "frames" in snapshot:
                # Frame restore would need custom logic
                pass

    def clear(self) -> None:
        """Clear all scene contents."""
        with self._lock:
            self._entity_manager.clear()
            self._frames.clear()
            self._metadata.clear()
            self._tick = 0
