"""
Resource management.

Provides strict resource lifecycle with reference counting.
"""

from __future__ import annotations
import threading
from typing import Dict, Any, Optional, TypeVar, Generic
from dataclasses import dataclass, field
from enum import Enum
from weakref import WeakValueDictionary

from astra.core.logging import get_logger
from astra.core.exceptions import ResourceError

logger = get_logger("resources")


class ResourceType(Enum):
    """Type of resource."""

    TEXTURE = "texture"
    MESH = "mesh"
    SHADER = "shader"
    AUDIO = "audio"
    DATA = "data"
    CUSTOM = "custom"


T = TypeVar("T")


@dataclass
class ResourceHandle:
    """Handle to a managed resource."""

    resource_id: str
    resource_type: ResourceType
    ref_count: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)


class _RefCountedResource:
    """Internal resource wrapper with reference counting."""

    def __init__(self, resource_id: str, resource_type: ResourceType, resource: Any):
        self.resource_id = resource_id
        self.resource_type = resource_type
        self.resource = resource
        self.ref_count = 1
        self.acquired_by: set[int] = {threading.get_ident()}

    def acquire(self) -> int:
        tid = threading.get_ident()
        if tid in self.acquired_by:
            self.ref_count += 1
        else:
            self.acquired_by.add(tid)
            self.ref_count += 1
        return self.ref_count

    def release(self) -> int:
        tid = threading.get_ident()
        if tid not in self.acquired_by:
            raise ResourceError(
                f"Release by non-acquiring thread for {self.resource_id}"
            )
        
        self.ref_count -= 1
        if self.ref_count <= 0:
            self.acquired_by.discard(tid)
        
        return self.ref_count


class ResourceManager:
    """
    Manages resources with strict lifecycle semantics.

    Provides:
    - Acquire/release with reference counting
    - Unknown resource detection
    - Double-release detection
    """

    def __init__(self, limit: int = 1000):
        self._limit = limit
        self._lock = threading.RLock()
        self._resources: Dict[str, _RefCountedResource] = {}
        self._handles: Dict[int, Dict[str, ResourceHandle]] = {}  # thread -> handles

    def register(
        self,
        resource_id: str,
        resource_type: ResourceType,
        resource: Any,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ResourceHandle:
        """Register a new resource."""
        with self._lock:
            if len(self._resources) >= self._limit:
                raise ResourceError(f"Resource limit reached: {self._limit}")
            
            if resource_id in self._resources:
                raise ResourceError(f"Resource already exists: {resource_id}")
            
            wrapped = _RefCountedResource(resource_id, resource_type, resource)
            self._resources[resource_id] = wrapped
            
            handle = ResourceHandle(
                resource_id=resource_id,
                resource_type=resource_type,
                ref_count=1,
                metadata=metadata or {},
            )
            
            # Track by current thread
            tid = threading.get_ident()
            if tid not in self._handles:
                self._handles[tid] = {}
            self._handles[tid][resource_id] = handle
            
            logger.debug(f"Registered resource: {resource_id}")
            return handle

    def acquire(self, resource_id: str) -> ResourceHandle:
        """Acquire a resource."""
        with self._lock:
            if resource_id not in self._resources:
                raise ResourceError(f"Unknown resource: {resource_id}")
            
            wrapped = self._resources[resource_id]
            new_count = wrapped.acquire()
            
            handle = ResourceHandle(
                resource_id=resource_id,
                resource_type=wrapped.resource_type,
                ref_count=new_count,
            )
            
            tid = threading.get_ident()
            if tid not in self._handles:
                self._handles[tid] = {}
            self._handles[tid][resource_id] = handle
            
            return handle

    def release(self, resource_id: str) -> bool:
        """
        Release a resource.

        Returns True if resource was fully released (ref count = 0).
        """
        with self._lock:
            if resource_id not in self._resources:
                raise ResourceError(f"Cannot release unknown resource: {resource_id}")
            
            wrapped = self._resources[resource_id]
            new_count = wrapped.release()
            
            # Remove from thread tracking
            tid = threading.get_ident()
            if tid in self._handles:
                self._handles[tid].pop(resource_id, None)
            
            if new_count <= 0:
                del self._resources[resource_id]
                logger.debug(f"Released resource: {resource_id}")
                return True
            
            return False

    def get(self, resource_id: str) -> Optional[Any]:
        """Get the underlying resource."""
        with self._lock:
            wrapped = self._resources.get(resource_id)
            return wrapped.resource if wrapped else None

    def get_handle(self, resource_id: str) -> Optional[ResourceHandle]:
        """Get handle for a resource."""
        with self._lock:
            wrapped = self._resources.get(resource_id)
            if not wrapped:
                return None
            
            return ResourceHandle(
                resource_id=resource_id,
                resource_type=wrapped.resource_type,
                ref_count=wrapped.ref_count,
            )

    def count(self) -> int:
        """Get number of active resources."""
        return len(self._resources)

    def clear(self) -> None:
        """Clear all resources."""
        with self._lock:
            self._resources.clear()
            self._handles.clear()
            logger.info("Cleared all resources")
