"""
Service registry and boundaries.

Provides service registration and lifecycle management.
"""

from __future__ import annotations
import threading
from typing import Dict, Any, Optional, Type, TypeVar
from dataclasses import dataclass
from enum import Enum

from astra.core.logging import get_logger
from astra.core.exceptions import AstraError

logger = get_logger("services")


class ServiceLifecycle(Enum):
    """Service lifecycle state."""

    CREATED = "created"
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


T = TypeVar("T", bound="Service")


class Service:
    """Base class for services."""

    def __init__(self, name: str):
        self.name = name
        self.lifecycle = ServiceLifecycle.CREATED

    def initialize(self) -> None:
        """Initialize the service."""
        self.lifecycle = ServiceLifecycle.INITIALIZING

    def start(self) -> None:
        """Start the service."""
        self.lifecycle = ServiceLifecycle.RUNNING

    def pause(self) -> None:
        """Pause the service."""
        self.lifecycle = ServiceLifecycle.PAUSED

    def resume(self) -> None:
        """Resume the service."""
        if self.lifecycle == ServiceLifecycle.PAUSED:
            self.lifecycle = ServiceLifecycle.RUNNING

    def stop(self) -> None:
        """Stop the service."""
        self.lifecycle = ServiceLifecycle.STOPPED


class ServiceRegistry:
    """Registry for engine services."""

    def __init__(self):
        self._lock = threading.RLock()
        self._services: Dict[str, Service] = {}

    def register(self, service: Service) -> bool:
        """Register a service."""
        with self._lock:
            if service.name in self._services:
                return False
            self._services[service.name] = service
            logger.debug(f"Registered service: {service.name}")
            return True

    def unregister(self, name: str) -> Optional[Service]:
        """Unregister a service."""
        with self._lock:
            service = self._services.pop(name, None)
            if service:
                logger.debug(f"Unregistered service: {name}")
            return service

    def get(self, name: str) -> Optional[Service]:
        """Get a service by name."""
        return self._services.get(name)

    def get_typed(self, service_type: Type[T]) -> Optional[T]:
        """Get a service by type."""
        with self._lock:
            for service in self._services.values():
                if isinstance(service, service_type):
                    return service
            return None

    def start_all(self) -> None:
        """Start all registered services."""
        with self._lock:
            for service in self._services.values():
                try:
                    service.initialize()
                    service.start()
                except Exception as e:
                    service.lifecycle = ServiceLifecycle.ERROR
                    logger.error(f"Failed to start {service.name}: {e}")

    def stop_all(self) -> None:
        """Stop all services."""
        with self._lock:
            for service in self._services.values():
                try:
                    service.stop()
                except Exception as e:
                    logger.error(f"Failed to stop {service.name}: {e}")

    def list_services(self) -> list[str]:
        """List all registered service names."""
        return list(self._services.keys())
