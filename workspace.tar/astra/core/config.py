"""
Engine configuration.

Provides configuration options for the ASTRA engine.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from enum import Enum


class DeterminismMode(Enum):
    """Determinism enforcement mode."""

    STRICT = "strict"  # Full determinism required, reject non-deterministic operations
    RELAXED = "relaxed"  # Best-effort determinism with warnings
    DISABLED = "disabled"  # No determinism guarantees


class AuthorityMode(Enum):
    """Authority enforcement mode."""

    ENFORCED = "enforced"  # Strict authority checks, raise on violations
    WARN = "warn"  # Log warnings on violations but allow
    DISABLED = "disabled"  # No authority checks


@dataclass
class EngineConfig:
    """
    Configuration for the ASTRA engine.

    Attributes:
        determinism_mode: How strictly to enforce determinism.
        authority_mode: How strictly to enforce simulation authority.
        max_command_history: Maximum number of commands to keep in history.
        enable_event_logging: Whether to log all events.
        persistence_path: Base path for persistence/snapshots.
        resource_limit: Maximum number of concurrent resources.
        recovery_policy: Default recovery policy for failures.
        custom_config: Additional custom configuration options.
    """

    determinism_mode: DeterminismMode = DeterminismMode.STRICT
    authority_mode: AuthorityMode = AuthorityMode.ENFORCED
    max_command_history: int = 10000
    enable_event_logging: bool = False
    persistence_path: str = "./astra_snapshots"
    resource_limit: int = 1000
    recovery_policy: str = "fail_fast"  # fail_fast, retry_step, drop_event
    custom_config: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> List[str]:
        """
        Validate the configuration.

        Returns:
            List of validation error messages (empty if valid).
        """
        errors = []

        if self.max_command_history < 1:
            errors.append("max_command_history must be at least 1")

        if self.resource_limit < 1:
            errors.append("resource_limit must be at least 1")

        if self.persistence_path is None:
            errors.append("persistence_path cannot be None")

        return errors

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EngineConfig":
        """Create configuration from a dictionary."""
        config_data = data.copy()

        # Convert string enums if needed
        if "determinism_mode" in config_data and isinstance(
            config_data["determinism_mode"], str
        ):
            config_data["determinism_mode"] = DeterminismMode(
                config_data["determinism_mode"]
            )

        if "authority_mode" in config_data and isinstance(
            config_data["authority_mode"], str
        ):
            config_data["authority_mode"] = AuthorityMode(
                config_data["authority_mode"]
            )

        # Extract custom config
        known_keys = {
            "determinism_mode",
            "authority_mode",
            "max_command_history",
            "enable_event_logging",
            "persistence_path",
            "resource_limit",
            "recovery_policy",
        }
        custom = {k: v for k, v in config_data.items() if k not in known_keys}

        # Filter to known keys for dataclass init
        filtered = {k: v for k, v in config_data.items() if k in known_keys}
        filtered["custom_config"] = custom

        return cls(**filtered)

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to a dictionary."""
        return {
            "determinism_mode": self.determinism_mode.value,
            "authority_mode": self.authority_mode.value,
            "max_command_history": self.max_command_history,
            "enable_event_logging": self.enable_event_logging,
            "persistence_path": self.persistence_path,
            "resource_limit": self.resource_limit,
            "recovery_policy": self.recovery_policy,
            **self.custom_config,
        }
