"""
Coordinate frame foundations.

Provides frame registration, identity, parent/child relationships,
and origin rebasing infrastructure.
"""

from __future__ import annotations
import threading
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum

from astra.core.logging import get_logger
from astra.core.exceptions import FrameError

logger = get_logger("coords")


@dataclass
class CoordinateTransform:
    """
    Represents a coordinate transformation between frames.

    For CORE, we provide the foundation without implementing
    full physics/astronomy transforms.
    """

    source_frame: str
    target_frame: str
    translation: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: Tuple[float, float, float] = (0.0, 0.0, 0.0)  # Euler angles
    scale: float = 1.0

    def apply(self, coords: Tuple[float, float, float]) -> Tuple[float, float, float]:
        """Apply transformation to coordinates (simplified)."""
        x, y, z = coords
        tx, ty, tz = self.translation
        
        # Simplified: just translation + scale
        # Full implementation would include rotation matrices
        return (
            (x * self.scale) + tx,
            (y * self.scale) + ty,
            (z * self.scale) + tz,
        )

    def inverse(self) -> "CoordinateTransform":
        """Create inverse transform."""
        return CoordinateTransform(
            source_frame=self.target_frame,
            target_frame=self.source_frame,
            translation=(-self.translation[0]/self.scale, 
                        -self.translation[1]/self.scale, 
                        -self.translation[2]/self.scale),
            rotation=(-self.rotation[0], -self.rotation[1], -self.rotation[2]),
            scale=1.0 / self.scale if self.scale != 0 else 1.0,
        )


@dataclass
class Frame:
    """
    A coordinate frame in the simulation.

    Frames have unique IDs and can have parent/child relationships.
    """

    frame_id: str
    name: str = ""
    parent_id: Optional[str] = None
    origin: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def snapshot(self) -> Dict[str, Any]:
        """Create serializable snapshot."""
        return {
            "frame_id": self.frame_id,
            "name": self.name,
            "parent_id": self.parent_id,
            "origin": self.origin,
            "metadata": self.metadata,
        }


class RebaseRequest:
    """
    Request for origin rebasing.

    Distinguishes REQUEST from EXECUTION as per specification.
    """

    def __init__(
        self,
        source_frame: str,
        target_origin: Tuple[float, float, float],
        reason: str = "",
    ):
        self.source_frame = source_frame
        self.target_origin = target_origin
        self.reason = reason
        self.executed = False
        self.result: Optional[Tuple[float, float, float]] = None

    def execute(self, registry: "FrameRegistry") -> Tuple[float, float, float]:
        """Execute the rebase request."""
        new_origin = registry.rebase_frame(self.source_frame, self.target_origin)
        self.executed = True
        self.result = new_origin
        return new_origin


class FrameRegistry:
    """
    Registry for coordinate frames.

    Manages frame creation, relationships, and transformations.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._frames: Dict[str, Frame] = {}
        self._children: Dict[str, List[str]] = {}  # parent -> children
        self._transforms: Dict[Tuple[str, str], CoordinateTransform] = {}

    def register_frame(
        self,
        frame_id: str,
        name: str = "",
        parent_id: Optional[str] = None,
        origin: Tuple[float, float, float] = (0.0, 0.0, 0.0),
    ) -> Frame:
        """Register a new frame."""
        with self._lock:
            if frame_id in self._frames:
                raise FrameError(f"Frame already exists: {frame_id}")
            
            if parent_id and parent_id not in self._frames:
                raise FrameError(f"Parent frame not found: {parent_id}")
            
            # Check for cycles
            if parent_id and self._would_create_cycle(frame_id, parent_id):
                raise FrameError(f"Cannot create cycle: {frame_id} -> {parent_id}")
            
            frame = Frame(
                frame_id=frame_id,
                name=name or frame_id,
                parent_id=parent_id,
                origin=origin,
            )
            self._frames[frame_id] = frame
            
            if parent_id:
                if parent_id not in self._children:
                    self._children[parent_id] = []
                self._children[parent_id].append(frame_id)
            
            logger.debug(f"Registered frame: {frame_id}")
            return frame

    def _would_create_cycle(self, new_frame: str, parent: str) -> bool:
        """Check if adding new_frame as child of parent would create a cycle."""
        current = parent
        visited = set()
        
        while current:
            if current == new_frame:
                return True
            if current in visited:
                break
            visited.add(current)
            frame = self._frames.get(current)
            if frame:
                current = frame.parent_id
            else:
                break
        
        return False

    def get_frame(self, frame_id: str) -> Optional[Frame]:
        """Get a frame by ID."""
        return self._frames.get(frame_id)

    def frame_exists(self, frame_id: str) -> bool:
        """Check if a frame exists."""
        return frame_id in self._frames

    def unregister_frame(self, frame_id: str) -> bool:
        """Unregister a frame."""
        with self._lock:
            if frame_id not in self._frames:
                return False
            
            frame = self._frames[frame_id]
            
            # Remove from parent's children
            if frame.parent_id and frame.parent_id in self._children:
                self._children[frame.parent_id].remove(frame_id)
            
            # Orphan children
            if frame_id in self._children:
                for child_id in self._children[frame_id]:
                    child = self._frames.get(child_id)
                    if child:
                        child.parent_id = frame.parent_id
                
                if frame.parent_id and frame.parent_id in self._children:
                    self._children[frame.parent_id].extend(self._children[frame_id])
                
                del self._children[frame_id]
            
            del self._frames[frame_id]
            return True

    def get_parent(self, frame_id: str) -> Optional[str]:
        """Get parent frame ID."""
        frame = self._frames.get(frame_id)
        return frame.parent_id if frame else None

    def get_children(self, frame_id: str) -> List[str]:
        """Get child frame IDs."""
        return list(self._children.get(frame_id, []))

    def register_transform(
        self,
        source: str,
        target: str,
        transform: CoordinateTransform,
    ) -> None:
        """Register a transform between frames."""
        with self._lock:
            if source not in self._frames:
                raise FrameError(f"Source frame not found: {source}")
            if target not in self._frames:
                raise FrameError(f"Target frame not found: {target}")
            
            self._transforms[(source, target)] = transform
            logger.debug(f"Registered transform: {source} -> {target}")

    def get_transform(
        self, source: str, target: str
    ) -> Optional[CoordinateTransform]:
        """Get transform between frames."""
        return self._transforms.get((source, target))

    def transform_coords(
        self,
        coords: Tuple[float, float, float],
        source: str,
        target: str,
    ) -> Tuple[float, float, float]:
        """Transform coordinates from source to target frame."""
        with self._lock:
            if source == target:
                return coords
            
            transform = self._transforms.get((source, target))
            if transform:
                return transform.apply(coords)
            
            # Try to find path through hierarchy
            return self._transform_through_hierarchy(coords, source, target)

    def _transform_through_hierarchy(
        self,
        coords: Tuple[float, float, float],
        source: str,
        target: str,
    ) -> Tuple[float, float, float]:
        """Transform coordinates through frame hierarchy."""
        # Simplified: walk up to common ancestor then down
        source_frame = self._frames.get(source)
        target_frame = self._frames.get(target)
        
        if not source_frame or not target_frame:
            raise FrameError(f"Unknown frame in transform: {source} or {target}")
        
        # Get ancestors
        source_ancestors = self._get_ancestors(source)
        target_ancestors = self._get_ancestors(target)
        
        # Find common ancestor
        common = None
        for anc in source_ancestors:
            if anc in target_ancestors:
                common = anc
                break
        
        if common is None:
            # No common ancestor, use world origin difference
            sx, sy, sz = source_frame.origin
            tx, ty, tz = target_frame.origin
            return (coords[0] - sx + tx, coords[1] - sy + ty, coords[2] - sz + tz)
        
        # Transform to common, then to target
        result = coords
        for frame_id in source_ancestors:
            if frame_id == common:
                break
            frame = self._frames.get(frame_id)
            if frame and frame.parent_id:
                px, py, pz = frame.origin
                result = (result[0] + px, result[1] + py, result[2] + pz)
        
        for frame_id in reversed(target_ancestors):
            if frame_id == common:
                break
            frame = self._frames.get(frame_id)
            if frame and frame.parent_id:
                px, py, pz = frame.origin
                result = (result[0] - px, result[1] - py, result[2] - pz)
        
        return result

    def _get_ancestors(self, frame_id: str) -> List[str]:
        """Get list of ancestor frame IDs."""
        ancestors = [frame_id]
        current = frame_id
        
        while True:
            frame = self._frames.get(current)
            if not frame or not frame.parent_id:
                break
            ancestors.append(frame.parent_id)
            current = frame.parent_id
        
        return ancestors

    def rebase_frame(
        self,
        frame_id: str,
        new_origin: Tuple[float, float, float],
    ) -> Tuple[float, float, float]:
        """
        Rebase a frame to a new origin.

        Changes coordinate representation while preserving physical positions.
        """
        with self._lock:
            frame = self._frames.get(frame_id)
            if not frame:
                raise FrameError(f"Frame not found: {frame_id}")
            
            old_origin = frame.origin
            frame.origin = new_origin
            
            logger.info(f"Rebased frame {frame_id}: {old_origin} -> {new_origin}")
            return new_origin

    def count(self) -> int:
        """Get frame count."""
        return len(self._frames)

    def get_all_frames(self) -> List[Frame]:
        """Get all frames."""
        with self._lock:
            return list(self._frames.values())

    def clear(self) -> None:
        """Clear all frames."""
        with self._lock:
            self._frames.clear()
            self._children.clear()
            self._transforms.clear()

    def snapshot(self) -> Dict[str, Any]:
        """Create serializable snapshot."""
        with self._lock:
            return {
                "frames": {fid: f.snapshot() for fid, f in self._frames.items()},
                "transforms": {
                    f"{s}->{t}": {
                        "source_frame": tr.source_frame,
                        "target_frame": tr.target_frame,
                        "translation": tr.translation,
                        "rotation": tr.rotation,
                        "scale": tr.scale,
                    }
                    for (s, t), tr in self._transforms.items()
                },
            }
