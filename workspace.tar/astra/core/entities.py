"""
Entity Component System (ECS) foundations.

Provides deterministic entity management with safe iteration.
"""

from __future__ import annotations
import threading
from typing import Dict, List, Set, Optional, Any, Type, TypeVar, Iterator
from dataclasses import dataclass, field
from copy import deepcopy

from astra.core.ids import generate_entity_id
from astra.core.logging import get_logger
from astra.core.exceptions import EntityError

logger = get_logger("entities")


@dataclass
class Component:
    """Base class for entity components."""

    component_type: str = ""

    def __post_init__(self):
        if not self.component_type:
            self.component_type = self.__class__.__name__


T = TypeVar("T", bound=Component)


@dataclass
class Entity:
    """
    An entity in the simulation.

    Entities are lightweight identifiers with attached components.
    """

    entity_id: str = field(default_factory=generate_entity_id)
    name: str = ""
    active: bool = True
    components: Dict[str, Component] = field(default_factory=dict)

    def add_component(self, component: Component) -> None:
        """Add a component to this entity."""
        self.components[component.component_type] = component

    def remove_component(self, component_type: str) -> Optional[Component]:
        """Remove a component by type."""
        return self.components.pop(component_type, None)

    def get_component(self, component_type: str) -> Optional[Component]:
        """Get a component by type."""
        return self.components.get(component_type)

    def has_component(self, component_type: str) -> bool:
        """Check if entity has a component type."""
        return component_type in self.components

    def snapshot(self) -> Dict[str, Any]:
        """Create a serializable snapshot."""
        return {
            "entity_id": self.entity_id,
            "name": self.name,
            "active": self.active,
            "components": {
                ctype: {"type": c.component_type, "data": vars(c)}
                for ctype, c in self.components.items()
            },
        }


class ComponentQuery:
    """Query for entities with specific components."""

    def __init__(self, *required_types: str, exclude_types: tuple = ()):
        self.required_types = set(required_types)
        self.exclude_types = set(exclude_types)

    def matches(self, entity: Entity) -> bool:
        """Check if an entity matches this query."""
        if not entity.active:
            return False
        
        entity_types = set(entity.components.keys())
        
        if not self.required_types.issubset(entity_types):
            return False
        
        if self.exclude_types.intersection(entity_types):
            return False
        
        return True


class EntityManager:
    """
    Manages entities and components.

    Provides thread-safe entity operations with safe iteration.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._entities: Dict[str, Entity] = {}
        self._destroyed: Set[str] = set()
        self._next_snapshot: List[Entity] = []  # For safe iteration

    def create_entity(
        self, name: str = "", components: Optional[List[Component]] = None
    ) -> Entity:
        """Create a new entity."""
        with self._lock:
            entity = Entity(name=name)
            if components:
                for comp in components:
                    entity.add_component(comp)
            self._entities[entity.entity_id] = entity
            logger.debug(f"Created entity: {entity.entity_id} ({name})")
            return entity

    def destroy_entity(self, entity_id: str) -> bool:
        """Destroy an entity by ID."""
        with self._lock:
            if entity_id not in self._entities:
                return False
            
            self._destroyed.add(entity_id)
            del self._entities[entity_id]
            logger.debug(f"Destroyed entity: {entity_id}")
            return True

    def get_entity(self, entity_id: str) -> Optional[Entity]:
        """Get an entity by ID."""
        return self._entities.get(entity_id)

    def entity_exists(self, entity_id: str) -> bool:
        """Check if an entity exists."""
        return entity_id in self._entities

    def query(self, query: ComponentQuery) -> List[Entity]:
        """Find all entities matching a query."""
        with self._lock:
            return [e for e in self._entities.values() if query.matches(e)]

    def query_single(self, query: ComponentQuery) -> Optional[Entity]:
        """Find first entity matching a query."""
        with self._lock:
            for entity in self._entities.values():
                if query.matches(entity):
                    return entity
            return None

    def count(self) -> int:
        """Get entity count."""
        return len(self._entities)

    def get_all_entities(self) -> List[Entity]:
        """Get all entities (snapshot for safe iteration)."""
        with self._lock:
            return list(self._entities.values())

    def iterate_safe(self) -> Iterator[Entity]:
        """
        Iterate over entities safely.

        Returns a snapshot to avoid modification during iteration.
        """
        with self._lock:
            snapshot = list(self._entities.values())
        
        yield from snapshot

    def add_component(
        self, entity_id: str, component: Component
    ) -> bool:
        """Add a component to an entity."""
        with self._lock:
            entity = self._entities.get(entity_id)
            if entity is None:
                raise EntityError(f"Entity not found: {entity_id}")
            entity.add_component(component)
            return True

    def remove_component(
        self, entity_id: str, component_type: str
    ) -> Optional[Component]:
        """Remove a component from an entity."""
        with self._lock:
            entity = self._entities.get(entity_id)
            if entity is None:
                raise EntityError(f"Entity not found: {entity_id}")
            return entity.remove_component(component_type)

    def clear(self) -> None:
        """Clear all entities."""
        with self._lock:
            self._entities.clear()
            self._destroyed.clear()

    def snapshot(self) -> Dict[str, Any]:
        """Create a serializable snapshot of all entities."""
        with self._lock:
            return {
                eid: entity.snapshot()
                for eid, entity in self._entities.items()
            }

    def restore(self, snapshot: Dict[str, Any]) -> None:
        """Restore entities from a snapshot."""
        with self._lock:
            self.clear()
            for eid, data in snapshot.items():
                entity = Entity(
                    entity_id=data["entity_id"],
                    name=data["name"],
                    active=data["active"],
                )
                for ctype, comp_data in data.get("components", {}).items():
                    # Restore as generic component
                    comp = Component(component_type=comp_data["type"])
                    for k, v in comp_data.get("data", {}).items():
                        setattr(comp, k, v)
                    entity.add_component(comp)
                self._entities[eid] = entity
