"""
Deterministic random number generation.

Provides isolated RNG streams to ensure determinism across subsystems.
"""

from __future__ import annotations
import random
import threading
from typing import Dict, Optional, List, Any
from dataclasses import dataclass, field
from copy import deepcopy

from astra.core.logging import get_logger

logger = get_logger("rng")


@dataclass
class RNGState:
    """Snapshot of RNG state for save/restore."""

    seed: int
    position: int
    stream_id: str
    class_name: str = "Random"


class RNGStream:
    """
    Isolated random number generator stream.

    Each stream has its own Random instance, ensuring that
    consumption by one subsystem doesn't affect another's sequence.
    """

    def __init__(self, stream_id: str, seed: int):
        self._stream_id = stream_id
        self._seed = seed
        self._rng = random.Random(seed)
        self._consumption_count = 0
        self._lock = threading.Lock()

    @property
    def stream_id(self) -> str:
        return self._stream_id

    @property
    def seed(self) -> int:
        return self._seed

    @property
    def consumption_count(self) -> int:
        return self._consumption_count

    def random(self) -> float:
        """Return a random float in [0.0, 1.0)."""
        with self._lock:
            self._consumption_count += 1
            return self._rng.random()

    def randint(self, a: int, b: int) -> int:
        """Return a random integer N such that a <= N <= b."""
        with self._lock:
            self._consumption_count += 1
            return self._rng.randint(a, b)

    def choice(self, seq: List[Any]) -> Any:
        """Return a random element from a non-empty sequence."""
        with self._lock:
            self._consumption_count += 1
            return self._rng.choice(seq)

    def shuffle(self, seq: List[Any]) -> None:
        """Shuffle a sequence in place."""
        with self._lock:
            self._consumption_count += 1
            self._rng.shuffle(seq)

    def gauss(self, mu: float = 0.0, sigma: float = 1.0) -> float:
        """Return a Gaussian distributed random number."""
        with self._lock:
            self._consumption_count += 1
            return self._rng.gauss(mu, sigma)

    def uniform(self, a: float, b: float) -> float:
        """Return a uniform random number in [a, b]."""
        with self._lock:
            self._consumption_count += 1
            return self._rng.uniform(a, b)

    def snapshot(self) -> RNGState:
        """Create a snapshot of the current RNG state."""
        with self._lock:
            # Get internal state position
            return RNGState(
                seed=self._seed,
                position=self._consumption_count,
                stream_id=self._stream_id,
                class_name=self._rng.__class__.__name__,
            )

    def restore(self, state: RNGState) -> None:
        """Restore RNG state from a snapshot."""
        with self._lock:
            if state.seed != self._seed:
                logger.warning(f"Restoring stream {self._stream_id} with different seed")
            # Recreate RNG and advance to position
            self._rng = random.Random(state.seed)
            self._consumption_count = state.position
            # Advance by consuming values
            for _ in range(state.position):
                self._rng.random()

    def reset(self) -> None:
        """Reset the stream to initial state."""
        with self._lock:
            self._rng = random.Random(self._seed)
            self._consumption_count = 0


class DeterministicRNG:
    """
    Manager for deterministic RNG streams.

    Provides isolated streams for different subsystems to prevent
    cross-contamination of random sequences.
    """

    def __init__(self, default_seed: int = 42):
        self._default_seed = default_seed
        self._streams: Dict[str, RNGStream] = {}
        self._lock = threading.Lock()
        self._stream_counter = 0

    def create_stream(
        self, name: Optional[str] = None, seed: Optional[int] = None
    ) -> RNGStream:
        """
        Create a new isolated RNG stream.

        Args:
            name: Optional name for the stream (auto-generated if not provided).
            seed: Optional seed (uses default if not provided).

        Returns:
            A new RNGStream instance.
        """
        with self._lock:
            if name is None:
                name = f"stream_{self._stream_counter:04d}"
                self._stream_counter += 1

            if name in self._streams:
                raise ValueError(f"RNG stream '{name}' already exists")

            stream_seed = seed if seed is not None else self._default_seed
            stream = RNGStream(name, stream_seed)
            self._streams[name] = stream
            logger.debug(f"Created RNG stream: {name} with seed {stream_seed}")
            return stream

    def get_stream(self, name: str) -> Optional[RNGStream]:
        """Get an existing stream by name."""
        return self._streams.get(name)

    def remove_stream(self, name: str) -> bool:
        """Remove a stream by name."""
        with self._lock:
            if name in self._streams:
                del self._streams[name]
                return True
            return False

    def snapshot_all(self) -> Dict[str, RNGState]:
        """Snapshot all stream states."""
        with self._lock:
            return {name: stream.snapshot() for name, stream in self._streams.items()}

    def restore_all(self, states: Dict[str, RNGState]) -> None:
        """Restore all stream states from snapshots."""
        with self._lock:
            for name, state in states.items():
                if name in self._streams:
                    self._streams[name].restore(state)
                else:
                    # Create new stream and restore
                    stream = RNGStream(name, state.seed)
                    stream.restore(state)
                    self._streams[name] = stream

    def reset_all(self) -> None:
        """Reset all streams to their initial state."""
        with self._lock:
            for stream in self._streams.values():
                stream.reset()

    def clear_all(self) -> None:
        """Clear all streams."""
        with self._lock:
            self._streams.clear()
            self._stream_counter = 0
