"""
Deterministic ID generation for entities, commands, and events.

IDs are generated sequentially to ensure deterministic ordering.
"""

from __future__ import annotations
import threading
from typing import Final


class _IDGenerator:
    """Thread-safe sequential ID generator."""

    def __init__(self, prefix: str = "id"):
        self._prefix = prefix
        self._counter = 0
        self._lock = threading.Lock()

    def next(self) -> str:
        """Generate the next ID in sequence."""
        with self._lock:
            id_str = f"{self._prefix}_{self._counter:012d}"
            self._counter += 1
            return id_str

    def reset(self) -> None:
        """Reset the counter (for testing/replay)."""
        with self._lock:
            self._counter = 0


# Global ID generators with distinct prefixes
_entity_generator: Final[_IDGenerator] = _IDGenerator("ent")
_command_generator: Final[_IDGenerator] = _IDGenerator("cmd")
_event_generator: Final[_IDGenerator] = _IDGenerator("evt")


def generate_entity_id() -> str:
    """Generate a unique entity ID."""
    return _entity_generator.next()


def generate_command_id() -> str:
    """Generate a unique command ID."""
    return _command_generator.next()


def generate_event_id() -> str:
    """Generate a unique event ID."""
    return _event_generator.next()


def reset_all_generators() -> None:
    """Reset all ID generators (for testing/replay)."""
    _entity_generator.reset()
    _command_generator.reset()
    _event_generator.reset()


def set_counter(prefix: str, value: int) -> None:
    """Set counter value for a specific prefix (for replay initialization)."""
    if prefix == "ent":
        with _entity_generator._lock:
            _entity_generator._counter = value
    elif prefix == "cmd":
        with _command_generator._lock:
            _command_generator._counter = value
    elif prefix == "evt":
        with _event_generator._lock:
            _event_generator._counter = value
