"""
Event system for ASTRA CORE.

Provides deterministic event dispatch for simulation events
and separate handling for external/I/O events.
"""

from __future__ import annotations
import threading
from typing import Dict, List, Callable, Any, Optional, Set
from dataclasses import dataclass, field
from enum import IntEnum
from collections import defaultdict
import weakref

from astra.core.ids import generate_event_id
from astra.core.logging import get_logger
from astra.core.exceptions import AstraError

logger = get_logger("events")


class Priority(IntEnum):
    """Event handler priority levels."""

    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    MONITOR = 4  # Lowest priority, for monitoring only


@dataclass
class Event:
    """
    Base class for all events.

    Attributes:
        event_id: Unique identifier for this event instance.
        event_type: Type name of the event.
        timestamp: Simulation time when the event was created.
        source: Source component/system that generated the event.
        data: Event payload data.
        is_simulation_event: Whether this is a deterministic simulation event.
    """

    event_id: str = field(default_factory=generate_event_id)
    event_type: str = ""
    timestamp: float = 0.0
    source: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    is_simulation_event: bool = True

    def __post_init__(self):
        if not self.event_type:
            self.event_type = self.__class__.__name__


EventHandler = Callable[[Event], None]


@dataclass
class HandlerRegistration:
    """Registration information for an event handler."""

    handler: EventHandler
    priority: Priority
    owner: Optional[str] = None
    enabled: bool = True


class EventBus:
    """
    Central event bus for publishing and subscribing to events.

    Distinguishes between:
    - Simulation Events: Must be deterministic, processed in order
    - External Events: I/O events that don't affect simulation state
    """

    def __init__(self):
        self._lock = threading.RLock()
        # Handlers organized by event type, then sorted by priority
        self._handlers: Dict[str, List[HandlerRegistration]] = defaultdict(list)
        self._all_handlers: List[HandlerRegistration] = []  # For wildcard subscriptions
        self._event_history: List[Event] = []
        self._max_history: int = 1000
        self._enabled: bool = True
        self._handler_ids: Dict[int, weakref.ref] = {}  # Track handlers for cleanup

    def subscribe(
        self,
        event_type: str,
        handler: EventHandler,
        priority: Priority = Priority.NORMAL,
        owner: Optional[str] = None,
    ) -> str:
        """
        Subscribe to events of a specific type.

        Args:
            event_type: Type of events to subscribe to (use '*' for all).
            handler: Callback function to invoke.
            priority: Handler priority (lower = higher priority).
            owner: Optional owner identifier for bulk unsubscribe.

        Returns:
            Subscription ID (handler id).
        """
        with self._lock:
            reg = HandlerRegistration(handler=handler, priority=priority, owner=owner)
            handler_id = id(handler)
            self._handler_ids[handler_id] = weakref.ref(handler)

            if event_type == "*":
                self._all_handlers.append(reg)
            else:
                handlers = self._handlers[event_type]
                handlers.append(reg)
                # Keep sorted by priority
                handlers.sort(key=lambda r: r.priority)

            logger.debug(f"Subscribed to {event_type} with priority {priority}")
            return str(handler_id)

    def unsubscribe(self, event_type: str, handler: EventHandler) -> bool:
        """
        Unsubscribe a handler from an event type.

        Args:
            event_type: Type of events to unsubscribe from.
            handler: The handler to remove.

        Returns:
            True if the handler was found and removed.
        """
        with self._lock:
            handler_id = id(handler)

            if event_type == "*":
                for i, reg in enumerate(self._all_handlers):
                    if reg.handler is handler or id(reg.handler) == handler_id:
                        self._all_handlers.pop(i)
                        self._handler_ids.pop(handler_id, None)
                        return True
            else:
                handlers = self._handlers.get(event_type, [])
                for i, reg in enumerate(handlers):
                    if reg.handler is handler or id(reg.handler) == handler_id:
                        handlers.pop(i)
                        self._handler_ids.pop(handler_id, None)
                        return True

            return False

    def unsubscribe_all(self, owner: str) -> int:
        """
        Unsubscribe all handlers owned by a specific owner.

        Args:
            owner: The owner identifier.

        Returns:
            Number of handlers unsubscribed.
        """
        count = 0
        with self._lock:
            # Remove from typed handlers
            for event_type, handlers in list(self._handlers.items()):
                original_len = len(handlers)
                self._handlers[event_type] = [
                    h for h in handlers if h.owner != owner
                ]
                count += original_len - len(self._handlers[event_type])

            # Remove from wildcard handlers
            original_len = len(self._all_handlers)
            self._all_handlers = [h for h in self._all_handlers if h.owner != owner]
            count += original_len - len(self._all_handlers)

        logger.debug(f"Unsubscribed {count} handlers for owner: {owner}")
        return count

    def publish(self, event: Event) -> None:
        """
        Publish an event to all subscribers.

        Args:
            event: The event to publish.
        """
        if not self._enabled:
            return

        with self._lock:
            # Record in history
            if len(self._event_history) >= self._max_history:
                self._event_history.pop(0)
            self._event_history.append(event)

            # Get handlers for this event type
            handlers = list(self._handlers.get(event.event_type, []))
            handlers.extend(self._all_handlers)

            # Sort by priority (already sorted, but merge might need it)
            handlers.sort(key=lambda r: r.priority)

        # Call handlers outside the lock to prevent deadlocks
        failed_handlers = []
        for reg in handlers:
            if not reg.enabled:
                continue
            try:
                reg.handler(event)
            except Exception as e:
                logger.error(f"Handler error for {event.event_type}: {e}")
                failed_handlers.append((reg, e))

        if failed_handlers and logger.isEnabledFor(10):  # DEBUG level
            for reg, error in failed_handlers:
                logger.debug(f"Failed handler: {reg.handler}, error: {error}")

    def clear_history(self) -> None:
        """Clear the event history."""
        with self._lock:
            self._event_history.clear()

    def get_history(
        self, event_type: Optional[str] = None, limit: int = 100
    ) -> List[Event]:
        """
        Get recent event history.

        Args:
            event_type: Filter by event type (None for all).
            limit: Maximum number of events to return.

        Returns:
            List of events, most recent first.
        """
        with self._lock:
            if event_type is None:
                return list(reversed(self._event_history[-limit:]))
            return list(
                reversed(
                    [e for e in self._event_history if e.event_type == event_type][
                        -limit:
                    ]
                )
            )

    def enable(self) -> None:
        """Enable event publishing."""
        self._enabled = True

    def disable(self) -> None:
        """Disable event publishing."""
        self._enabled = False

    @property
    def is_enabled(self) -> bool:
        """Check if event publishing is enabled."""
        return self._enabled
