"""
Simulation time system.

Provides simulation clock with different time modes.
"""

from __future__ import annotations
import threading
import time as real_time
from typing import Optional, Callable
from dataclasses import dataclass
from enum import Enum

from astra.core.logging import get_logger
from astra.core.exceptions import TimeError

logger = get_logger("time")


class TimeMode(Enum):
    """Simulation time mode."""

    INTERNAL_REALTIME = "internal_realtime"  # Sim time matches real time
    INTERNAL_DETERMINISTIC = "internal_deterministic"  # Fixed timestep
    EXTERNAL_SYNC = "external_sync"  # Sync to external timestamps


@dataclass
class Timestamp:
    """A point in simulation time."""

    tick: int = 0
    simulation_time: float = 0.0
    real_time: float = 0.0

    def __lt__(self, other: "Timestamp") -> bool:
        return self.simulation_time < other.simulation_time


class SimulationClock:
    """
    Manages simulation time.

    Supports multiple time modes and provides pause/resume/seek functionality.
    """

    def __init__(
        self,
        mode: TimeMode = TimeMode.INTERNAL_DETERMINISTIC,
        tick_rate: float = 60.0,
    ):
        self._lock = threading.RLock()
        self._mode = mode
        self._tick_rate = tick_rate
        self._tick_duration = 1.0 / tick_rate if tick_rate > 0 else 0.0
        
        self._current_tick: int = 0
        self._simulation_time: float = 0.0
        self._real_time_start: float = 0.0
        self._paused: bool = False
        self._paused_at: float = 0.0
        self._accumulated_pause_time: float = 0.0
        
        self._running: bool = False
        self._callbacks: list[Callable[[int, float], None]] = []

    @property
    def mode(self) -> TimeMode:
        return self._mode

    @property
    def tick_rate(self) -> float:
        return self._tick_rate

    @property
    def current_tick(self) -> int:
        return self._current_tick

    @property
    def simulation_time(self) -> float:
        return self._simulation_time

    @property
    def is_paused(self) -> bool:
        return self._paused

    @property
    def is_running(self) -> bool:
        return self._running

    def start(self) -> None:
        """Start the simulation clock."""
        with self._lock:
            if self._running:
                return
            
            self._running = True
            self._real_time_start = real_time.time()
            self._paused = False
            self._accumulated_pause_time = 0.0
            logger.info(f"Simulation clock started in mode: {self._mode}")

    def stop(self) -> None:
        """Stop the simulation clock."""
        with self._lock:
            self._running = False
            logger.info("Simulation clock stopped")

    def pause(self) -> None:
        """Pause the simulation clock."""
        with self._lock:
            if self._paused or not self._running:
                return
            
            self._paused = True
            self._paused_at = real_time.time()
            logger.debug(f"Simulation paused at tick {self._current_tick}")

    def resume(self) -> None:
        """Resume the simulation clock."""
        with self._lock:
            if not self._paused or not self._running:
                return
            
            pause_end = real_time.time()
            self._accumulated_pause_time += (pause_end - self._paused_at)
            self._paused = False
            logger.debug(f"Simulation resumed")

    def advance(self, ticks: int = 1) -> int:
        """
        Advance simulation by specified ticks.

        Args:
            ticks: Number of ticks to advance.

        Returns:
            New tick count.
        """
        with self._lock:
            if not self._running:
                raise TimeError("Cannot advance: clock not running")
            
            if self._paused:
                raise TimeError("Cannot advance: clock is paused")
            
            for _ in range(ticks):
                self._current_tick += 1
                self._simulation_time += self._tick_duration
                
                # Notify callbacks
                for callback in self._callbacks:
                    try:
                        callback(self._current_tick, self._simulation_time)
                    except Exception as e:
                        logger.error(f"Tick callback error: {e}")
            
            return self._current_tick

    def seek(self, tick: int) -> None:
        """
        Seek to a specific tick (for replay/timeline).

        Note: This is timeline seeking, NOT physical time travel.
        """
        with self._lock:
            if not self._running:
                raise TimeError("Cannot seek: clock not running")
            
            if tick < 0:
                raise TimeError(f"Invalid tick: {tick}")
            
            old_tick = self._current_tick
            self._current_tick = tick
            self._simulation_time = tick * self._tick_duration
            
            logger.info(f"Seek from tick {old_tick} to {tick}")

    def set_mode(self, mode: TimeMode) -> None:
        """Set the time mode."""
        with self._lock:
            self._mode = mode
            logger.info(f"Time mode changed to: {mode}")

    def update_external_timestamp(self, timestamp: float) -> None:
        """
        Update from external timestamp (EXTERNAL_SYNC mode).

        Args:
            timestamp: External monotonic timestamp.
        """
        with self._lock:
            if self._mode != TimeMode.EXTERNAL_SYNC:
                logger.warning("update_external_timestamp called in wrong mode")
                return
            
            # Basic monotonicity check
            if timestamp < self._simulation_time:
                raise TimeError(
                    f"Non-monotonic timestamp: {timestamp} < {self._simulation_time}"
                )
            
            self._simulation_time = timestamp

    def get_timestamp(self) -> Timestamp:
        """Get current timestamp."""
        with self._lock:
            real_t = 0.0
            if self._running and not self._paused:
                real_t = real_time.time() - self._real_time_start - self._accumulated_pause_time
            
            return Timestamp(
                tick=self._current_tick,
                simulation_time=self._simulation_time,
                real_time=real_t,
            )

    def register_tick_callback(self, callback: Callable[[int, float], None]) -> None:
        """Register a callback for tick events."""
        self._callbacks.append(callback)

    def unregister_tick_callback(
        self, callback: Callable[[int, float], None]
    ) -> bool:
        """Unregister a tick callback."""
        try:
            self._callbacks.remove(callback)
            return True
        except ValueError:
            return False

    def reset(self) -> None:
        """Reset clock to initial state."""
        with self._lock:
            self._current_tick = 0
            self._simulation_time = 0.0
            self._real_time_start = 0.0
            self._paused = False
            self._paused_at = 0.0
            self._accumulated_pause_time = 0.0
            logger.info("Simulation clock reset")

    def snapshot(self) -> dict:
        """Create serializable snapshot."""
        with self._lock:
            return {
                "mode": self._mode.value,
                "tick_rate": self._tick_rate,
                "current_tick": self._current_tick,
                "simulation_time": self._simulation_time,
                "paused": self._paused,
                "running": self._running,
                "accumulated_pause_time": self._accumulated_pause_time,
            }

    def restore(self, snapshot: dict) -> None:
        """Restore from snapshot."""
        with self._lock:
            self._mode = TimeMode(snapshot.get("mode", "internal_deterministic"))
            self._tick_rate = snapshot.get("tick_rate", 60.0)
            self._tick_duration = 1.0 / self._tick_rate if self._tick_rate > 0 else 0.0
            self._current_tick = snapshot.get("current_tick", 0)
            self._simulation_time = snapshot.get("simulation_time", 0.0)
            self._paused = snapshot.get("paused", False)
            self._running = snapshot.get("running", False)
            self._accumulated_pause_time = snapshot.get("accumulated_pause_time", 0.0)
