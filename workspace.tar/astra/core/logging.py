"""
Logging infrastructure for ASTRA CORE.

Provides structured logging with configurable levels.
"""

from __future__ import annotations
import logging
import sys
from enum import IntEnum
from typing import Optional, Dict, Any
from threading import Lock


class LogLevel(IntEnum):
    """Log level enumeration matching standard logging levels."""

    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL


_logger_lock = Lock()
_loggers: Dict[str, logging.Logger] = {}
_default_level: LogLevel = LogLevel.INFO


def _create_logger(name: str) -> logging.Logger:
    """Create a configured logger for the given name."""
    logger = logging.getLogger(f"astra.{name}")
    logger.setLevel(_default_level)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(_default_level)
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger


def get_logger(name: str = "core") -> logging.Logger:
    """
    Get a logger instance for the specified module/component.

    Args:
        name: The name of the logger (prepended with 'astra.')

    Returns:
        A configured Logger instance.
    """
    with _logger_lock:
        if name not in _loggers:
            _loggers[name] = _create_logger(name)
        return _loggers[name]


def set_log_level(level: LogLevel) -> None:
    """
    Set the default log level for all ASTRA loggers.

    Args:
        level: The desired log level.
    """
    global _default_level
    with _logger_lock:
        _default_level = level
        for logger in _loggers.values():
            for handler in logger.handlers:
                handler.setLevel(level)
            logger.setLevel(level)


def configure_logging(
    level: Optional[LogLevel] = None,
    log_to_file: Optional[str] = None,
    format_string: Optional[str] = None,
) -> None:
    """
    Configure ASTRA logging globally.

    Args:
        level: Default log level.
        log_to_file: Optional file path for file logging.
        format_string: Optional custom format string.
    """
    global _default_level

    if level is not None:
        _default_level = level

    root_logger = logging.getLogger("astra")
    root_logger.setLevel(level or _default_level)

    # Clear existing handlers
    root_logger.handlers.clear()

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level or _default_level)
    console_formatter = logging.Formatter(
        format_string or "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)

    # File handler if requested
    if log_to_file:
        file_handler = logging.FileHandler(log_to_file)
        file_handler.setLevel(level or _default_level)
        file_handler.setFormatter(console_formatter)
        root_logger.addHandler(file_handler)

    # Reset cached loggers
    with _logger_lock:
        _loggers.clear()
