"""
Deterministic command system.

Commands provide ordered, replayable operations on simulation state.
"""

from __future__ import annotations
import threading
from typing import Dict, List, Callable, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import deque

from astra.core.ids import generate_command_id
from astra.core.logging import get_logger
from astra.core.exceptions import CommandError

logger = get_logger("commands")


class CommandType(Enum):
    """Type of command for categorization."""

    ENTITY_CREATE = "entity_create"
    ENTITY_DESTROY = "entity_destroy"
    COMPONENT_ADD = "component_add"
    COMPONENT_REMOVE = "component_remove"
    TRANSFORM = "transform"
    REBASE_REQUEST = "rebase_request"
    TIME_CONTROL = "time_control"
    CUSTOM = "custom"


@dataclass
class Command:
    """
    A deterministic command for simulation operations.

    Attributes:
        command_id: Unique identifier for this command.
        command_type: Type of command.
        tick: Simulation tick when command was issued.
        sequence: Sequence number within the tick.
        payload: Command-specific data.
        executed: Whether the command has been executed.
        result: Result of command execution (if any).
    """

    command_type: CommandType
    payload: Dict[str, Any] = field(default_factory=dict)
    command_id: str = field(default_factory=generate_command_id)
    tick: int = 0
    sequence: int = 0
    executed: bool = False
    result: Any = None

    def __post_init__(self):
        if not isinstance(self.command_type, CommandType):
            self.command_type = CommandType.CUSTOM

    def __lt__(self, other: "Command") -> bool:
        """Compare commands by tick then sequence for ordering."""
        if self.tick != other.tick:
            return self.tick < other.tick
        return self.sequence < other.sequence


CommandHandler = Callable[[Command], Any]


class CommandDispatcher:
    """
    Dispatches commands to appropriate handlers.

    Maintains deterministic ordering and supports replay.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._handlers: Dict[CommandType, List[CommandHandler]] = {}
        self._pending_commands: deque[Command] = deque()
        self._current_tick: int = 0
        self._sequence_counter: int = 0

    def register_handler(
        self, command_type: CommandType, handler: CommandHandler
    ) -> None:
        """Register a handler for a command type."""
        with self._lock:
            if command_type not in self._handlers:
                self._handlers[command_type] = []
            self._handlers[command_type].append(handler)
            logger.debug(f"Registered handler for {command_type}")

    def unregister_handler(
        self, command_type: CommandType, handler: CommandHandler
    ) -> bool:
        """Unregister a handler."""
        with self._lock:
            if command_type in self._handlers:
                try:
                    self._handlers[command_type].remove(handler)
                    return True
                except ValueError:
                    pass
            return False

    def issue(
        self,
        command_type: CommandType,
        payload: Dict[str, Any] = None,
        tick: Optional[int] = None,
    ) -> Command:
        """
        Issue a new command.

        Args:
            command_type: Type of command.
            payload: Command data.
            tick: Optional tick override (for replay).

        Returns:
            The created Command.
        """
        with self._lock:
            cmd = Command(
                command_type=command_type,
                payload=payload or {},
                tick=tick if tick is not None else self._current_tick,
                sequence=self._sequence_counter,
            )
            self._sequence_counter += 1
            self._pending_commands.append(cmd)
            logger.debug(f"Issued command: {cmd.command_id} ({command_type.value})")
            return cmd

    def execute_pending(self) -> List[Tuple[Command, Any]]:
        """
        Execute all pending commands.

        Returns:
            List of (command, result) tuples.
        """
        results = []
        with self._lock:
            # Sort pending by tick, sequence
            pending = sorted(self._pending_commands)
            self._pending_commands.clear()

            for cmd in pending:
                result = self._execute_command(cmd)
                cmd.executed = True
                cmd.result = result
                results.append((cmd, result))

        return results

    def _execute_command(self, cmd: Command) -> Any:
        """Execute a single command."""
        handlers = self._handlers.get(cmd.command_type, [])
        if not handlers:
            logger.warning(f"No handlers for command type: {cmd.command_type}")
            return None

        results = []
        for handler in handlers:
            try:
                result = handler(cmd)
                results.append(result)
            except Exception as e:
                logger.error(f"Command handler error: {e}")
                raise CommandError(f"Command execution failed: {e}")

        return results[0] if len(results) == 1 else results

    def advance_tick(self) -> int:
        """Advance to the next tick."""
        with self._lock:
            self._current_tick += 1
            self._sequence_counter = 0
            return self._current_tick

    @property
    def current_tick(self) -> int:
        return self._current_tick

    def reset(self) -> None:
        """Reset dispatcher state."""
        with self._lock:
            self._pending_commands.clear()
            self._current_tick = 0
            self._sequence_counter = 0


class CommandHistory:
    """
    Maintains history of executed commands for replay.
    """

    def __init__(self, max_size: int = 10000):
        self._max_size = max_size
        self._lock = threading.RLock()
        self._history: List[Command] = []
        self._by_tick: Dict[int, List[Command]] = {}

    def record(self, cmd: Command) -> None:
        """Record an executed command."""
        with self._lock:
            self._history.append(cmd)
            
            if cmd.tick not in self._by_tick:
                self._by_tick[cmd.tick] = []
            self._by_tick[cmd.tick].append(cmd)

            # Trim if over limit
            while len(self._history) > self._max_size:
                old_cmd = self._history.pop(0)
                if old_cmd.tick in self._by_tick:
                    self._by_tick[old_cmd.tick].remove(old_cmd)
                    if not self._by_tick[old_cmd.tick]:
                        del self._by_tick[old_cmd.tick]

    def get_commands_at_tick(self, tick: int) -> List[Command]:
        """Get all commands at a specific tick."""
        with self._lock:
            return list(self._by_tick.get(tick, []))

    def get_commands_in_range(
        self, start_tick: int, end_tick: Optional[int] = None
    ) -> List[Command]:
        """Get commands in a tick range."""
        with self._lock:
            if end_tick is None:
                end_tick = start_tick
            
            result = []
            for tick in range(start_tick, end_tick + 1):
                result.extend(self._by_tick.get(tick, []))
            return sorted(result)

    def get_all_commands(self) -> List[Command]:
        """Get all recorded commands."""
        with self._lock:
            return list(self._history)

    def clear(self) -> None:
        """Clear all history."""
        with self._lock:
            self._history.clear()
            self._by_tick.clear()

    def snapshot(self) -> Dict[str, Any]:
        """Create a serializable snapshot of history."""
        with self._lock:
            return {
                "max_size": self._max_size,
                "commands": [
                    {
                        "command_id": c.command_id,
                        "command_type": c.command_type.value,
                        "tick": c.tick,
                        "sequence": c.sequence,
                        "payload": c.payload,
                        "executed": c.executed,
                        "result": c.result,
                    }
                    for c in self._history
                ],
            }

    def restore(self, snapshot: Dict[str, Any]) -> None:
        """Restore from a snapshot."""
        with self._lock:
            self.clear()
            self._max_size = snapshot.get("max_size", 10000)
            
            for cmd_data in snapshot.get("commands", []):
                cmd = Command(
                    command_type=CommandType(cmd_data["command_type"]),
                    payload=cmd_data.get("payload", {}),
                    command_id=cmd_data["command_id"],
                    tick=cmd_data.get("tick", 0),
                    sequence=cmd_data.get("sequence", 0),
                    executed=cmd_data.get("executed", False),
                    result=cmd_data.get("result"),
                )
                self._history.append(cmd)
                if cmd.tick not in self._by_tick:
                    self._by_tick[cmd.tick] = []
                self._by_tick[cmd.tick].append(cmd)
